// MBC1 — supports up to 2MB ROM (125 usable banks) and up to 32KB external RAM.
//
// Control "registers" aren't real memory — writes into ROM address space are
// intercepted and just change banking state:
//   0x0000-0x1FFF  RAM enable        (lower nibble 0x0A enables, anything else disables)
//   0x2000-0x3FFF  ROM bank number   (lower 5 bits; 0 is treated as 1 — you can
//                                     never bank-select 0 into the switchable window)
//   0x4000-0x5FFF  RAM bank number, OR the upper 2 bits of a large ROM bank
//                                     number — which one depends on banking mode
//   0x6000-0x7FFF  Banking mode select (0 = ROM banking, 1 = RAM banking)

export class MBC1 {
  constructor(romBytes) {
    this.rom = romBytes;
    this.ram = new Uint8Array(0x8000); // 4 banks x 8KB — allocated even if the cart has less
    this.ramEnabled = false;
    this.romBankLow5 = 1;
    this.upperBits = 0;  // 2 bits: RAM bank number, or upper ROM bank bits, depending on mode
    this.bankingMode = 0; // 0 = ROM banking mode, 1 = RAM banking mode
  }

  get romBank() {
    let bank = this.romBankLow5 || 1; // 0 => treated as 1
    if (this.bankingMode === 0) bank |= (this.upperBits << 5);
    return bank;
  }

  get ramBank() {
    return this.bankingMode === 1 ? this.upperBits : 0;
  }

  // Reads from ROM address space (0x0000-0x7FFF).
  readROM(addr) {
    if (addr < 0x4000) {
      // Fixed bank 0, EXCEPT: in RAM-banking mode with a large ROM, the upper
      // bits can also bank-switch this low window. Handle that case too.
      const bank = (this.bankingMode === 1) ? (this.upperBits << 5) : 0;
      const offset = bank * 0x4000 + addr;
      return this.rom[offset] ?? 0xFF;
    }
    const offset = this.romBank * 0x4000 + (addr - 0x4000);
    return this.rom[offset] ?? 0xFF;
  }

  // Writes into ROM address space are banking control, not actual writes.
  writeControl(addr, value) {
    if (addr < 0x2000) {
      this.ramEnabled = (value & 0x0F) === 0x0A;
    } else if (addr < 0x4000) {
      this.romBankLow5 = value & 0x1F;
    } else if (addr < 0x6000) {
      this.upperBits = value & 0x03;
    } else if (addr < 0x8000) {
      this.bankingMode = value & 0x01;
    }
  }

  readRAM(addr) {
    if (!this.ramEnabled) return 0xFF;
    return this.ram[this.ramBank * 0x2000 + (addr - 0xA000)];
  }

  writeRAM(addr, value) {
    if (!this.ramEnabled) return;
    this.ram[this.ramBank * 0x2000 + (addr - 0xA000)] = value & 0xFF;
  }
}
