// APU (Audio Processing Unit) — 4 channels: two square waves (CH1 has a
// frequency sweep, CH2 doesn't), one wave channel (CH3, plays 32 4-bit
// samples from wave RAM), and one noise channel (CH4, LFSR-based).
//
// Design split, since audio has to come out at a fixed 44.1kHz regardless of
// how fast/slow emulation is running:
//   - step(cycles) advances the 512Hz "frame sequencer" that clocks length
//     counters, the volume envelopes, and CH1's frequency sweep. This keeps
//     those time-based behaviors correct even if audio itself lags.
//   - The actual waveform (square/wave/noise samples) is synthesized live,
//     sample-by-sample, inside the Web Audio callback — reading whatever the
//     current frequency/volume/duty state is at that moment. This decouples
//     audio generation from CPU emulation speed entirely.
//
// Register addresses (all live directly in mmu.io, no separate storage):
//   CH1: NR10 0xFF10  NR11 0xFF11  NR12 0xFF12  NR13 0xFF13  NR14 0xFF14
//   CH2: NR21 0xFF16  NR22 0xFF17  NR23 0xFF18  NR24 0xFF19
//   CH3: NR30 0xFF1A  NR31 0xFF1B  NR32 0xFF1C  NR33 0xFF1D  NR34 0xFF1E
//   CH4: NR41 0xFF20  NR42 0xFF21  NR43 0xFF22  NR44 0xFF23
//   NR50 0xFF24 (master volume/panning) NR51 0xFF25 (per-channel panning)
//   NR52 0xFF26 (master on/off + read-only channel-active status)
//   Wave RAM: 0xFF30-0xFF3F (32 4-bit samples)

const DUTY_PATTERNS = [
  [0, 0, 0, 0, 0, 0, 0, 1], // 12.5%
  [1, 0, 0, 0, 0, 0, 0, 1], // 25%
  [1, 0, 0, 0, 0, 1, 1, 1], // 50%
  [0, 1, 1, 1, 1, 1, 1, 0], // 75%
];

const NOISE_DIVISORS = [8, 16, 32, 48, 64, 80, 96, 112];

const FRAME_SEQUENCER_PERIOD = 8192; // CPU cycles per frame-sequencer step (512 Hz)

export class APU {
  constructor(mmu) {
    this.mmu = mmu;
    this.frameSeqCycles = 0;
    this.frameSeqStep = 0;

    this.ch1 = { lengthCounter: 0, volume: 0, envelopeTimer: 0, sweepTimer: 0, sweepFreqShadow: 0, sweepEnabled: false, enabled: false, phase: 0 };
    this.ch2 = { lengthCounter: 0, volume: 0, envelopeTimer: 0, enabled: false, phase: 0 };
    this.ch3 = { lengthCounter: 0, enabled: false, phase: 0 };
    this.ch4 = { lengthCounter: 0, volume: 0, envelopeTimer: 0, enabled: false, lfsr: 0x7FFF, phase: 0 };

    this.audioCtx = null;
    this.scriptNode = null;
  }

  // Must be called from a user-gesture handler (e.g. the ROM file input's
  // change event counts) — browsers block audio until one occurs.
  start() {
    if (this.audioCtx) return;
    this.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    // ScriptProcessorNode is deprecated but needs no extra module file to load,
    // which keeps this scaffold self-contained. Swap for an AudioWorklet later
    // if you want to remove the deprecation / cut main-thread audio glitches.
    this.scriptNode = this.audioCtx.createScriptProcessor(2048, 0, 2);
    this.scriptNode.onaudioprocess = (e) => this.renderAudio(e);
    this.scriptNode.connect(this.audioCtx.destination);
  }

  // --- Frame sequencer: called once per CPU step with however many cycles elapsed ---
  step(cycles) {
    this.frameSeqCycles += cycles;
    while (this.frameSeqCycles >= FRAME_SEQUENCER_PERIOD) {
      this.frameSeqCycles -= FRAME_SEQUENCER_PERIOD;
      this.tickFrameSequencer();
    }
  }

  tickFrameSequencer() {
    // Step: 0   1   2   3   4   5   6   7
    // Length: X       X       X       X   (every step, 256Hz)
    // Sweep:      X           X           (every other length step, 128Hz)
    // Envelope:                       X   (64Hz)
    if (this.frameSeqStep % 2 === 0) this.tickLengthCounters();
    if (this.frameSeqStep === 2 || this.frameSeqStep === 6) this.tickSweep();
    if (this.frameSeqStep === 7) this.tickEnvelopes();
    this.frameSeqStep = (this.frameSeqStep + 1) % 8;
  }

  tickLengthCounters() {
    const io = this.mmu.io;
    for (const [ch, lengthEnableAddr] of [
      [this.ch1, 0x14], [this.ch2, 0x19], [this.ch3, 0x1E], [this.ch4, 0x23],
    ]) {
      const lengthEnabled = (io[lengthEnableAddr] & 0x40) !== 0;
      if (lengthEnabled && ch.lengthCounter > 0) {
        ch.lengthCounter--;
        if (ch.lengthCounter === 0) ch.enabled = false;
      }
    }
    this.updateNR52Status();
  }

  tickSweep() {
    const ch = this.ch1;
    if (!ch.sweepEnabled) return;
    const nr10 = this.mmu.io[0x10];
    const period = (nr10 >> 4) & 0x07;
    if (period === 0) return;

    if (ch.sweepTimer > 0) ch.sweepTimer--;
    if (ch.sweepTimer === 0) {
      ch.sweepTimer = period;
      const direction = (nr10 & 0x08) ? -1 : 1;
      const shift = nr10 & 0x07;
      const delta = ch.sweepFreqShadow >> shift;
      const newFreq = ch.sweepFreqShadow + direction * delta;

      if (newFreq > 2047) {
        ch.enabled = false; // sweep overflow disables the channel
      } else if (shift > 0) {
        ch.sweepFreqShadow = newFreq;
        this.mmu.io[0x13] = newFreq & 0xFF;
        this.mmu.io[0x14] = (this.mmu.io[0x14] & 0xF8) | ((newFreq >> 8) & 0x07);
      }
    }
    this.updateNR52Status();
  }

  tickEnvelopes() {
    for (const [ch, nrAddr] of [[this.ch1, 0x12], [this.ch2, 0x17], [this.ch4, 0x21]]) {
      const nr = this.mmu.io[nrAddr];
      const period = nr & 0x07;
      if (period === 0) continue;
      const direction = (nr & 0x08) ? 1 : -1;

      if (ch.envelopeTimer > 0) ch.envelopeTimer--;
      if (ch.envelopeTimer === 0) {
        ch.envelopeTimer = period;
        const newVolume = ch.volume + direction;
        if (newVolume >= 0 && newVolume <= 15) ch.volume = newVolume;
      }
    }
  }

  updateNR52Status() {
    let bits = 0;
    if (this.ch1.enabled) bits |= 0x01;
    if (this.ch2.enabled) bits |= 0x02;
    if (this.ch3.enabled) bits |= 0x04;
    if (this.ch4.enabled) bits |= 0x08;
    this.mmu.io[0x26] = (this.mmu.io[0x26] & 0xF0) | bits;
  }

  // --- Register write hooks (MMU calls this for any write in 0xFF10-0xFF3F) ---
  onRegisterWrite(addr, value) {
    if (addr === 0x14 && (value & 0x80)) this.triggerCh1();
    if (addr === 0x19 && (value & 0x80)) this.triggerCh2();
    if (addr === 0x1E && (value & 0x80)) this.triggerCh3();
    if (addr === 0x23 && (value & 0x80)) this.triggerCh4();
  }

  triggerCh1() {
    const ch = this.ch1;
    const io = this.mmu.io;
    ch.enabled = (io[0x12] & 0xF8) !== 0; // DAC enabled if top 5 bits of NR12 are nonzero
    ch.lengthCounter = ch.lengthCounter || (64 - (io[0x11] & 0x3F));
    ch.volume = (io[0x12] >> 4) & 0x0F;
    ch.envelopeTimer = io[0x12] & 0x07;
    ch.sweepFreqShadow = io[0x13] | ((io[0x14] & 0x07) << 8);
    ch.sweepTimer = (io[0x10] >> 4) & 0x07;
    ch.sweepEnabled = ((io[0x10] >> 4) & 0x07) > 0 || (io[0x10] & 0x07) > 0;
    this.updateNR52Status();
  }

  triggerCh2() {
    const ch = this.ch2;
    const io = this.mmu.io;
    ch.enabled = (io[0x17] & 0xF8) !== 0;
    ch.lengthCounter = ch.lengthCounter || (64 - (io[0x16] & 0x3F));
    ch.volume = (io[0x17] >> 4) & 0x0F;
    ch.envelopeTimer = io[0x17] & 0x07;
    this.updateNR52Status();
  }

  triggerCh3() {
    const ch = this.ch3;
    const io = this.mmu.io;
    ch.enabled = (io[0x1A] & 0x80) !== 0;
    ch.lengthCounter = ch.lengthCounter || (256 - io[0x1B]);
    ch.phase = 0;
    this.updateNR52Status();
  }

  triggerCh4() {
    const ch = this.ch4;
    const io = this.mmu.io;
    ch.enabled = (io[0x21] & 0xF8) !== 0;
    ch.lengthCounter = ch.lengthCounter || (64 - (io[0x20] & 0x3F));
    ch.volume = (io[0x21] >> 4) & 0x0F;
    ch.envelopeTimer = io[0x21] & 0x07;
    ch.lfsr = 0x7FFF;
    this.updateNR52Status();
  }

  // --- Live waveform synthesis, called by the Web Audio callback ---
  renderAudio(event) {
    const left = event.outputBuffer.getChannelData(0);
    const right = event.outputBuffer.getChannelData(1);
    const sampleRate = this.audioCtx.sampleRate;
    const io = this.mmu.io;

    const masterOn = (io[0x26] & 0x80) !== 0;
    const nr50 = io[0x24];
    const leftVol = ((nr50 >> 4) & 0x07) / 7;
    const rightVol = (nr50 & 0x07) / 7;
    const panning = io[0x25];

    for (let i = 0; i < left.length; i++) {
      if (!masterOn) { left[i] = 0; right[i] = 0; continue; }

      const s1 = this.sampleCh1(sampleRate);
      const s2 = this.sampleCh2(sampleRate);
      const s3 = this.sampleCh3(sampleRate);
      const s4 = this.sampleCh4(sampleRate);

      let l = 0, r = 0;
      if (panning & 0x10) l += s1; if (panning & 0x01) r += s1;
      if (panning & 0x20) l += s2; if (panning & 0x02) r += s2;
      if (panning & 0x40) l += s3; if (panning & 0x04) r += s3;
      if (panning & 0x80) l += s4; if (panning & 0x08) r += s4;

      left[i] = (l / 4) * leftVol;
      right[i] = (r / 4) * rightVol;
    }
  }

  sampleCh1(sampleRate) {
    const ch = this.ch1;
    if (!ch.enabled) return 0;
    const io = this.mmu.io;
    const freqRaw = io[0x13] | ((io[0x14] & 0x07) << 8);
    const freqHz = 131072 / (2048 - freqRaw);
    const duty = DUTY_PATTERNS[(io[0x11] >> 6) & 0x03];

    ch.phase = (ch.phase + freqHz / sampleRate) % 1;
    const step = Math.floor(ch.phase * 8);
    return duty[step] ? (ch.volume / 15) : -(ch.volume / 15);
  }

  sampleCh2(sampleRate) {
    const ch = this.ch2;
    if (!ch.enabled) return 0;
    const io = this.mmu.io;
    const freqRaw = io[0x18] | ((io[0x19] & 0x07) << 8);
    const freqHz = 131072 / (2048 - freqRaw);
    const duty = DUTY_PATTERNS[(io[0x16] >> 6) & 0x03];

    ch.phase = (ch.phase + freqHz / sampleRate) % 1;
    const step = Math.floor(ch.phase * 8);
    return duty[step] ? (ch.volume / 15) : -(ch.volume / 15);
  }

  sampleCh3(sampleRate) {
    const ch = this.ch3;
    if (!ch.enabled) return 0;
    const io = this.mmu.io;
    if (!(io[0x1A] & 0x80)) return 0; // DAC off

    const freqRaw = io[0x1D] | ((io[0x1E] & 0x07) << 8);
    const freqHz = 65536 / (2048 - freqRaw);
    ch.phase = (ch.phase + freqHz / sampleRate) % 1;

    const sampleIndex = Math.floor(ch.phase * 32);
    const byteIndex = 0x30 + Math.floor(sampleIndex / 2);
    const byte = io[byteIndex];
    const nibble = (sampleIndex % 2 === 0) ? (byte >> 4) : (byte & 0x0F);

    const volumeShift = { 0: 4, 1: 0, 2: 1, 3: 2 }[(io[0x1C] >> 5) & 0x03]; // 0=mute,1=100%,2=50%,3=25%
    const level = (nibble >> volumeShift) / 15;
    return (level * 2) - 1; // center around 0
  }

  sampleCh4(sampleRate) {
    const ch = this.ch4;
    if (!ch.enabled) return 0;
    const io = this.mmu.io;
    const nr43 = io[0x22];
    const shiftClock = (nr43 >> 4) & 0x0F;
    const widthMode = (nr43 & 0x08) !== 0;
    const divisorCode = nr43 & 0x07;
    const freqHz = 262144 / (NOISE_DIVISORS[divisorCode] << shiftClock);

    // Advance the LFSR at the noise frequency, tracked via an accumulator
    // stashed on the channel object (reuses `phase` as a generic accumulator).
    ch.phase += freqHz / sampleRate;
    while (ch.phase >= 1) {
      ch.phase -= 1;
      const bit = (ch.lfsr & 0x01) ^ ((ch.lfsr >> 1) & 0x01);
      ch.lfsr >>= 1;
      ch.lfsr |= bit << 14;
      if (widthMode) { ch.lfsr &= ~(1 << 6); ch.lfsr |= bit << 6; }
    }

    const output = (ch.lfsr & 0x01) ? 1 : -1;
    return output * (ch.volume / 15);
  }
}
