// Joypad (P1/JOYP register, 0xFF00).
//
// The CPU selects which group of 4 buttons it wants to read by writing to
// bits 4-5 (0 = that group selected — inverted logic, same as the button
// lines below). Reading back gives bits 0-3 for whichever group(s) are
// selected, also inverted: 0 = pressed, 1 = released. Bits 6-7 are unused
// and always read as 1.
//
//   bit 7-6: unused (always 1)
//   bit 5:   select button keys (A/B/Select/Start)   0=selected
//   bit 4:   select direction keys (dpad)             0=selected
//   bit 3:   Down / Start   (0=pressed)
//   bit 2:   Up / Select    (0=pressed)
//   bit 1:   Left / B       (0=pressed)
//   bit 0:   Right / A      (0=pressed)

export class Joypad {
  constructor(mmu) {
    this.mmu = mmu;
    this.buttons = {
      right: false, left: false, up: false, down: false,
      a: false, b: false, select: false, start: false,
    };
  }

  // Call this from keyboard event handlers: setButton('a', true) on keydown,
  // setButton('a', false) on keyup. Fires the Joypad interrupt on press,
  // matching real hardware (a button going low can wake the CPU from HALT).
  setButton(name, pressed) {
    if (!(name in this.buttons)) return;
    const wasPressed = this.buttons[name];
    this.buttons[name] = pressed;
    if (pressed && !wasPressed) this.mmu.requestInterrupt(4);
  }

  // Computes the live P1 register value from current button state and
  // whichever select bits the CPU last wrote. MMU.readByte(0xFF00) calls this.
  readRegister() {
    const selectBits = this.mmu.io[0x00] & 0x30;
    let lowNibble = 0x0F;

    if (!(selectBits & 0x10)) { // direction keys selected
      if (this.buttons.right) lowNibble &= ~0x01;
      if (this.buttons.left)  lowNibble &= ~0x02;
      if (this.buttons.up)    lowNibble &= ~0x04;
      if (this.buttons.down)  lowNibble &= ~0x08;
    }
    if (!(selectBits & 0x20)) { // button keys selected
      if (this.buttons.a)      lowNibble &= ~0x01;
      if (this.buttons.b)      lowNibble &= ~0x02;
      if (this.buttons.select) lowNibble &= ~0x04;
      if (this.buttons.start)  lowNibble &= ~0x08;
    }

    return 0xC0 | selectBits | lowNibble;
  }
}
