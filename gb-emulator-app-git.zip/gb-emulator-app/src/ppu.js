// PPU (Picture Processing Unit) — renders the 160x144 LCD, scanline by scanline.
//
// Timing model: each visible line takes 456 dots, split into modes:
//   Mode 2 (OAM search)     dots   0-79   (80 dots)
//   Mode 3 (pixel transfer) dots  80-251  (172 dots, simplified fixed length)
//   Mode 0 (HBlank)         dots 252-455  (204 dots)
// Lines 144-153 are Mode 1 (VBlank). 154 lines total per frame (70224 dots).
//
// I/O registers (all live in mmu.io, addr - 0xFF00):
//   LCDC 0x40  STAT 0x41  SCY 0x42  SCX 0x43  LY 0x44  LYC 0x45
//   BGP  0x47  OBP0 0x48  OBP1 0x49  WY 0x4A  WX 0x4B
//
// CGB adds: BG map attribute bytes (VRAM bank 1, same map address as the
// DMG tile number in bank 0), and 8 BG + 8 OBJ color palettes accessed via
// mmu.bgPalette / mmu.objPalette (see mmu.js's BCPS/BCPD/OCPS/OCPD).

const MODE_HBLANK = 0, MODE_VBLANK = 1, MODE_OAM = 2, MODE_TRANSFER = 3;
const DOTS_OAM = 80, DOTS_TRANSFER = 172, DOTS_PER_LINE = 456, LINES_PER_FRAME = 154;

// Classic DMG 4-shade green palette (shade 0 = lightest, 3 = darkest), as RGBA bytes.
// Only used when the loaded game isn't running in CGB color mode.
const SHADE_COLORS = [
  [0x9b, 0xbc, 0x0f, 255],
  [0x8b, 0xac, 0x0f, 255],
  [0x30, 0x62, 0x30, 255],
  [0x0f, 0x38, 0x0f, 255],
];

export class PPU {
  constructor(mmu) {
    this.mmu = mmu;
    this.dotsThisLine = 0;
    this.windowLine = 0; // internal window scanline counter (separate from LY)
    this.framebuffer = new Uint8ClampedArray(160 * 144 * 4);
    this.frameReady = false;
  }

  // --- I/O register convenience getters (read live from mmu.io each time) ---
  get lcdc() { return this.mmu.io[0x40]; }
  get stat() { return this.mmu.io[0x41]; }
  set stat(v) { this.mmu.io[0x41] = v; }
  get scy() { return this.mmu.io[0x42]; }
  get scx() { return this.mmu.io[0x43]; }
  get ly() { return this.mmu.io[0x44]; }
  set ly(v) { this.mmu.io[0x44] = v; }
  get lyc() { return this.mmu.io[0x45]; }
  get bgp() { return this.mmu.io[0x47]; }
  get obp0() { return this.mmu.io[0x48]; }
  get obp1() { return this.mmu.io[0x49]; }
  get wy() { return this.mmu.io[0x4A]; }
  get wx() { return this.mmu.io[0x4B]; }

  get lcdEnabled() { return (this.lcdc & 0x80) !== 0; }
  get cgbMode() { return this.mmu.isCGB; }

  // Advances the PPU by `cycles` CPU dots. Call this once per CPU step with
  // however many cycles that instruction took, so PPU timing stays in sync.
  step(cycles) {
    if (!this.lcdEnabled) return;

    this.dotsThisLine += cycles;

    if (this.dotsThisLine >= DOTS_PER_LINE) {
      this.dotsThisLine -= DOTS_PER_LINE;
      this.advanceLine();
    }

    this.updateMode();
  }

  advanceLine() {
    this.ly = (this.ly + 1) % LINES_PER_FRAME;

    if (this.ly === 144) {
      this.mmu.requestInterrupt(0); // VBlank interrupt
      this.frameReady = true;
    }
    if (this.ly === 0) {
      this.windowLine = 0;
    }

    this.checkLYC();
  }

  checkLYC() {
    const coincidence = this.ly === this.lyc;
    this.stat = coincidence ? (this.stat | 0x04) : (this.stat & ~0x04);
    if (coincidence && (this.stat & 0x40)) this.mmu.requestInterrupt(1); // STAT interrupt (LYC match)
  }

  updateMode() {
    let mode;
    if (this.ly >= 144) {
      mode = MODE_VBLANK;
    } else if (this.dotsThisLine < DOTS_OAM) {
      mode = MODE_OAM;
    } else if (this.dotsThisLine < DOTS_OAM + DOTS_TRANSFER) {
      mode = MODE_TRANSFER;
      if ((this.stat & 0x03) !== MODE_TRANSFER) this.renderScanline(this.ly); // render once, on entry
    } else {
      mode = MODE_HBLANK;
    }

    const prevMode = this.stat & 0x03;
    if (mode !== prevMode) {
      this.stat = (this.stat & ~0x03) | mode;
      // STAT interrupt sources: bit3=HBlank bit4=VBlank bit5=OAM
      if (mode === MODE_HBLANK && (this.stat & 0x08)) this.mmu.requestInterrupt(1);
      if (mode === MODE_VBLANK && (this.stat & 0x10)) this.mmu.requestInterrupt(1);
      if (mode === MODE_OAM && (this.stat & 0x20)) this.mmu.requestInterrupt(1);
    }
  }

  // --- Scanline rendering ---
  renderScanline(line) {
    const bgColorIds = new Uint8Array(160);   // color id (0-3, pre-palette) per pixel, for sprite priority checks
    const bgPriority = new Uint8Array(160);   // CGB "BG-to-OAM priority" bit per pixel (this BG tile always wins over sprites)
    if (this.lcdc & 0x01) this.renderBackground(line, bgColorIds, bgPriority);
    if (this.lcdc & 0x20) this.renderWindow(line, bgColorIds, bgPriority);
    if (this.lcdc & 0x02) this.renderSprites(line, bgColorIds, bgPriority);
  }

  renderBackground(line, bgColorIds, bgPriority) {
    const tileMapBase = (this.lcdc & 0x08) ? 0x9C00 : 0x9800;
    const y = (line + this.scy) & 0xFF;
    const tileRow = Math.floor(y / 8);

    for (let x = 0; x < 160; x++) {
      const scrolledX = (x + this.scx) & 0xFF;
      const tileCol = Math.floor(scrolledX / 8);
      const mapAddr = tileMapBase + tileRow * 32 + tileCol;
      const tileIndex = this.mmu.readByte(mapAddr);
      const attr = this.cgbMode ? this.mmu.readVRAMBank(1, mapAddr) : 0;

      const colorId = this.readTilePixelAttr(tileIndex, scrolledX % 8, y % 8, attr, false);
      bgColorIds[x] = colorId;
      bgPriority[x] = (attr & 0x80) ? 1 : 0;
      this.setPixel(x, line, this.bgColor(colorId, attr));
    }
  }

  renderWindow(line, bgColorIds, bgPriority) {
    if (line < this.wy) return;
    const wxAdjusted = this.wx - 7;
    if (wxAdjusted >= 160) return;

    const tileMapBase = (this.lcdc & 0x40) ? 0x9C00 : 0x9800;
    const tileRow = Math.floor(this.windowLine / 8);
    let drewAny = false;

    for (let x = Math.max(0, wxAdjusted); x < 160; x++) {
      const winX = x - wxAdjusted;
      const tileCol = Math.floor(winX / 8);
      const mapAddr = tileMapBase + tileRow * 32 + tileCol;
      const tileIndex = this.mmu.readByte(mapAddr);
      const attr = this.cgbMode ? this.mmu.readVRAMBank(1, mapAddr) : 0;

      const colorId = this.readTilePixelAttr(tileIndex, winX % 8, this.windowLine % 8, attr, false);
      bgColorIds[x] = colorId;
      bgPriority[x] = (attr & 0x80) ? 1 : 0;
      this.setPixel(x, line, this.bgColor(colorId, attr));
      drewAny = true;
    }
    if (drewAny) this.windowLine++;
  }

  renderSprites(line, bgColorIds, bgPriority) {
    const spriteHeight = (this.lcdc & 0x04) ? 16 : 8;
    const sprites = [];

    for (let i = 0; i < 40 && sprites.length < 10; i++) {
      const base = i * 4;
      const spriteY = this.mmu.oam[base] - 16;
      const spriteX = this.mmu.oam[base + 1] - 8;
      const tileIndex = this.mmu.oam[base + 2];
      const attrs = this.mmu.oam[base + 3];

      if (line >= spriteY && line < spriteY + spriteHeight) {
        sprites.push({ spriteX, spriteY, tileIndex, attrs, oamIndex: i });
      }
    }

    if (this.cgbMode) {
      // CGB sprite priority is purely OAM order (lower index = higher
      // priority); X-coordinate isn't a factor like it is on DMG.
      sprites.sort((a, b) => b.oamIndex - a.oamIndex);
    } else {
      // DMG: lower X = higher priority, OAM index breaks ties. Draw
      // lowest-priority first so higher-priority sprites overwrite them.
      sprites.sort((a, b) => b.spriteX - a.spriteX);
    }

    for (const sprite of sprites) {
      const { spriteX, spriteY, attrs } = sprite;
      let tileIndex = sprite.tileIndex;
      const flipY = (attrs & 0x40) !== 0;
      const flipX = (attrs & 0x20) !== 0;
      const behindBG = (attrs & 0x80) !== 0;
      // DMG: bit4 picks OBP0/OBP1. CGB: bits0-2 pick one of 8 OBJ palettes,
      // and bit3 picks which VRAM bank the tile data comes from.
      const dmgPalette = (attrs & 0x10) ? this.obp1 : this.obp0;
      const cgbPaletteNum = attrs & 0x07;
      const objVRAMBank = this.cgbMode ? ((attrs & 0x08) ? 1 : 0) : 0;

      let row = line - spriteY;
      if (flipY) row = spriteHeight - 1 - row;

      if (spriteHeight === 16) {
        tileIndex &= 0xFE; // 8x16 sprites ignore bit 0 of the tile index
        if (row >= 8) { tileIndex += 1; row -= 8; }
      }

      for (let col = 0; col < 8; col++) {
        const x = spriteX + col;
        if (x < 0 || x >= 160) continue;

        const srcCol = flipX ? 7 - col : col;
        const colorId = this.readTilePixel(tileIndex, srcCol, row, objVRAMBank, true);
        if (colorId === 0) continue; // color 0 is transparent for sprites

        // BG-to-OAM priority: on CGB, an individual BG tile can force
        // itself above all sprites via its attribute byte, independent of
        // this sprite's own behindBG bit (only applies when LCDC bit0 — BG
        // master priority — is on).
        const bgForcedOnTop = this.cgbMode && (this.lcdc & 0x01) && bgPriority[x] && bgColorIds[x] !== 0;
        if (bgForcedOnTop) continue;
        if (behindBG && bgColorIds[x] !== 0) continue; // hidden behind non-zero BG pixel

        const color = this.cgbMode
          ? this.paletteColor(this.mmu.objPalette, cgbPaletteNum, colorId)
          : this.applyPalette(colorId, dmgPalette, this.mmu.dmgTheme
              ? ((attrs & 0x10) ? this.mmu.dmgTheme.obj1 : this.mmu.dmgTheme.obj0)
              : SHADE_COLORS);
        this.setPixel(x, line, color);
      }
    }
  }

  // Reads one pixel's 2-bit color id from tile data, taking a CGB BG
  // attribute byte into account for VRAM bank + tile flipping.
  readTilePixelAttr(tileIndex, x, y, attr, useObjAddressing) {
    const vramBank = (attr & 0x08) ? 1 : 0;
    if (attr & 0x20) x = 7 - x; // CGB horizontal flip
    if (attr & 0x40) y = 7 - y; // CGB vertical flip
    return this.readTilePixel(tileIndex, x, y, vramBank, useObjAddressing);
  }

  // Reads one pixel's 2-bit color id from tile data.
  // useObjAddressing=true always uses the unsigned 0x8000 base (sprites always do).
  readTilePixel(tileIndex, x, y, vramBank = 0, useObjAddressing = false) {
    let addr;
    if (useObjAddressing || (this.lcdc & 0x10)) {
      addr = 0x8000 + tileIndex * 16;
    } else {
      addr = 0x9000 + this.toSigned8(tileIndex) * 16;
    }
    addr += y * 2;

    const lowByte = this.mmu.readVRAMBank(vramBank, addr);
    const highByte = this.mmu.readVRAMBank(vramBank, addr + 1);
    const bit = 7 - x;
    const lo = (lowByte >> bit) & 1;
    const hi = (highByte >> bit) & 1;
    return (hi << 1) | lo;
  }

  toSigned8(byte) { return byte < 128 ? byte : byte - 256; }

  applyPalette(colorId, paletteReg, colorSet = SHADE_COLORS) {
    const shade = (paletteReg >> (colorId * 2)) & 0x03;
    return colorSet[shade];
  }

  // Resolves a BG/window pixel's final color: CGB uses its palette RAM
  // (selected by the tile's attribute byte), DMG uses BGP — through either
  // the classic green shades or, if this game has an auto-colorization
  // theme assigned (see dmg-colorization.js), that theme's BG palette.
  bgColor(colorId, attr) {
    if (this.cgbMode) return this.paletteColor(this.mmu.bgPalette, attr & 0x07, colorId);
    const colorSet = this.mmu.dmgTheme ? this.mmu.dmgTheme.bg : SHADE_COLORS;
    return this.applyPalette(colorId, this.bgp, colorSet);
  }

  // Converts one CGB palette entry (RGB555, little-endian, 2 bytes) to RGBA8888.
  paletteColor(paletteRAM, paletteNum, colorId) {
    const offset = paletteNum * 8 + colorId * 2;
    const lo = paletteRAM[offset];
    const hi = paletteRAM[offset + 1];
    const rgb555 = lo | (hi << 8);
    const r5 = rgb555 & 0x1F;
    const g5 = (rgb555 >> 5) & 0x1F;
    const b5 = (rgb555 >> 10) & 0x1F;
    // 5-bit to 8-bit: scale so 0x1F maps to 0xFF, not just a left-shift.
    return [(r5 * 255) / 31 | 0, (g5 * 255) / 31 | 0, (b5 * 255) / 31 | 0, 255];
  }

  setPixel(x, y, [r, g, b, a]) {
    const i = (y * 160 + x) * 4;
    this.framebuffer[i] = r;
    this.framebuffer[i + 1] = g;
    this.framebuffer[i + 2] = b;
    this.framebuffer[i + 3] = a;
  }
}
