// Timer — two independent counters:
//   DIV  (0xFF04) — the visible upper 8 bits of a 16-bit counter that free-runs
//                    at the full 4.194304 MHz CPU clock (so DIV itself ticks at
//                    16384 Hz). Any write resets the whole 16-bit counter to 0.
//   TIMA (0xFF05) — increments at a rate selected by TAC (0xFF07), reloads from
//                    TMA (0xFF06) and fires the Timer interrupt when it overflows.

const TIMA_THRESHOLDS = [1024, 16, 64, 256]; // CPU cycles per TIMA tick, indexed by TAC bits 0-1

export class Timer {
  constructor(mmu) {
    this.mmu = mmu;
    this.internalCounter = 0; // 16-bit; DIV register is the high byte of this
    this.timaAccumulator = 0;
  }

  get tima() { return this.mmu.io[0x05]; }
  set tima(v) { this.mmu.io[0x05] = v & 0xFF; }
  get tma() { return this.mmu.io[0x06]; }
  get tac() { return this.mmu.io[0x07]; }
  get timerEnabled() { return (this.tac & 0x04) !== 0; }

  step(cycles) {
    if (this.mmu.divWriteReset) {
      this.internalCounter = 0;
      this.timaAccumulator = 0;
      this.mmu.divWriteReset = false;
    }

    this.internalCounter = (this.internalCounter + cycles) & 0xFFFF;
    this.mmu.io[0x04] = (this.internalCounter >> 8) & 0xFF;

    if (!this.timerEnabled) return;

    const threshold = TIMA_THRESHOLDS[this.tac & 0x03];
    this.timaAccumulator += cycles;

    while (this.timaAccumulator >= threshold) {
      this.timaAccumulator -= threshold;
      const next = this.tima + 1;
      if (next > 0xFF) {
        this.tima = this.tma; // reload
        this.mmu.requestInterrupt(2); // Timer interrupt
      } else {
        this.tima = next;
      }
    }
  }
}
