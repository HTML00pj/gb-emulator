// Memory Management Unit — routes reads/writes across the GB's 64KB address space.
// Map:
//   0000-3FFF  ROM bank 0 (or MBC-controlled, see mbc.readROM)
//   4000-7FFF  ROM bank N, switchable via MBC
//   8000-9FFF  VRAM (2 banks on CGB, switchable via 0xFF4F)
//   A000-BFFF  External RAM (cartridge, via MBC if present)
//   C000-CFFF  Work RAM bank 0 (fixed)
//   D000-DFFF  Work RAM bank 1-7 on CGB (switchable via 0xFF70), bank 1 fixed on DMG
//   E000-FDFF  Echo RAM (mirrors C000-DDFF)
//   FE00-FE9F  OAM (sprite attribute table)
//   FEA0-FEFF  Unusable
//   FF00-FF7F  I/O registers
//   FF80-FFFE  High RAM (HRAM)
//   FFFF       Interrupt Enable register

import { MBC1 } from './mbc1.js';
import { MBC2 } from './mbc2.js';
import { MBC3 } from './mbc3.js';
import { MBC5 } from './mbc5.js';
import { pickDMGTheme } from './dmg-colorization.js';

// Cartridge header byte 0x0147 identifies which MBC (if any) the cart uses.
// This covers every common commercial MBC; anything more exotic falls back
// to ROM-only behavior (works fine for small homebrew ROMs).
const MBC1_TYPES = new Set([0x01, 0x02, 0x03]); // MBC1 / MBC1+RAM / MBC1+RAM+BATTERY
const MBC2_TYPES = new Set([0x05, 0x06]); // MBC2 / MBC2+BATTERY
const MBC3_TYPES = new Set([0x0F, 0x10, 0x11, 0x12, 0x13]); // MBC3(+TIMER)(+RAM)(+BATTERY) variants
const MBC5_TYPES = new Set([0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E]); // MBC5(+RAM)(+BATTERY)(+RUMBLE) variants

export class MMU {
  constructor() {
    this.rom = new Uint8Array(0x8000);   // used directly only when there's no MBC (ROM-only carts)

    // VRAM: 2 banks on CGB (bank 1 holds BG map attributes + can hold tile
    // data for CGB-only tiles), 1 bank used on DMG. Bank select is CPU-side
    // only (register 0xFF4F) — the PPU reads both banks directly regardless
    // of which bank the CPU currently has selected.
    this.vram = [new Uint8Array(0x2000), new Uint8Array(0x2000)];
    this.vramBank = 0;

    this.eram = new Uint8Array(0x2000);  // used directly only when there's no MBC

    // WRAM: 8 banks of 4KB on CGB. C000-CFFF is always bank 0; D000-DFFF
    // selects bank 1-7 via SVBK (0xFF70, value 0 is treated as 1). On DMG
    // this just always sits on bank 1, which reproduces the old flat 8KB
    // C000-DFFF behavior exactly.
    this.wram = Array.from({ length: 8 }, () => new Uint8Array(0x1000));
    this.wramBank = 1;

    this.oam = new Uint8Array(0xA0);
    this.io = new Uint8Array(0x80);
    this.hram = new Uint8Array(0x7F);
    this.ie = 0;
    this.divWriteReset = false; // set by writeByte(0xFF04,...), consumed by Timer.step()
    this.joypad = null; // set by main.js once a Joypad instance exists; readByte(0xFF00) defers to it
    this.apu = null; // set by main.js once an APU instance exists; writes to 0xFF10-0xFF3F notify it
    this.mbc = null; // set by loadROM() if the cartridge header indicates a supported MBC

    // --- CGB-only state ---
    this.isCGB = false; // set by loadROM() from the cartridge header

    // Auto-colorization theme for non-CGB games (see dmg-colorization.js).
    // Stays null for actual CGB games, which use real palette RAM instead.
    this.dmgTheme = null;

    // BG/OBJ color palette RAM: 8 palettes x 4 colors x 2 bytes each (RGB555,
    // little-endian), accessed indirectly through BCPS/BCPD (0xFF68/69) and
    // OCPS/OCPD (0xFF6A/6B) rather than being memory-mapped directly.
    this.bgPalette = new Uint8Array(64);
    this.objPalette = new Uint8Array(64);
    this.bgPaletteIndex = 0;
    this.bgPaletteAutoInc = false;
    this.objPaletteIndex = 0;
    this.objPaletteAutoInc = false;

    // CGB double-speed mode: games arm a switch via KEY1 (0xFF4D) then
    // execute STOP; the CPU picks this up (see cpu.js) and toggles doubleSpeed.
    this.doubleSpeed = false;
    this.speedSwitchArmed = false;

    // HDMA/GDMA (0xFF51-0xFF55): CGB's fast VRAM-bound DMA. Real hardware
    // can do this gradually during HBlank so the CPU keeps running; we do
    // both General-Purpose and HBlank-mode transfers instantly on trigger.
    // Simplification: this will be visually wrong for the rare effect that
    // depends on HDMA landing mid-scanline (raster-style tricks), but loads
    // tile/map data correctly for everything else.
    this.hdmaSrc = 0;
    this.hdmaDst = 0;
  }

  loadROM(bytes) {
    this.isCGB = bytes[0x0143] === 0x80 || bytes[0x0143] === 0xC0;
    this.dmgTheme = this.isCGB ? null : pickDMGTheme(bytes);

    const cartType = bytes[0x0147];
    if (MBC1_TYPES.has(cartType)) {
      this.mbc = new MBC1(bytes);
    } else if (MBC2_TYPES.has(cartType)) {
      this.mbc = new MBC2(bytes);
    } else if (MBC3_TYPES.has(cartType)) {
      this.mbc = new MBC3(bytes);
    } else if (MBC5_TYPES.has(cartType)) {
      this.mbc = new MBC5(bytes);
    } else {
      this.mbc = null;
      this.rom.set(bytes.subarray(0, Math.min(bytes.length, this.rom.length)));
    }
  }

  // Maps a C000-DFFF-space offset (0x0000-0x1FFF) to the right WRAM bank.
  // Used both for the direct C000-DFFF region and for the E000-FDFF echo.
  readWRAM(offset) {
    if (offset < 0x1000) return this.wram[0][offset];
    return this.wram[this.wramBank][offset - 0x1000];
  }
  writeWRAM(offset, value) {
    if (offset < 0x1000) { this.wram[0][offset] = value; return; }
    this.wram[this.wramBank][offset - 0x1000] = value;
  }

  // Reads a byte from a specific VRAM bank regardless of the current VBK
  // selection. The PPU needs this for CGB BG map attributes, which always
  // live in bank 1 no matter what the CPU has selected.
  readVRAMBank(bank, addr) {
    return this.vram[bank][addr - 0x8000];
  }

  readByte(addr) {
    addr &= 0xFFFF;
    if (addr < 0x8000) return this.mbc ? this.mbc.readROM(addr) : this.rom[addr];
    if (addr < 0xA000) return this.vram[this.vramBank][addr - 0x8000];
    if (addr < 0xC000) return this.mbc ? this.mbc.readRAM(addr) : this.eram[addr - 0xA000];
    if (addr < 0xE000) return this.readWRAM(addr - 0xC000);
    if (addr < 0xFE00) return this.readWRAM(addr - 0xE000); // echo RAM
    if (addr < 0xFEA0) return this.oam[addr - 0xFE00];
    if (addr < 0xFF00) return 0xFF; // unusable
    if (addr < 0xFF80) {
      if (addr === 0xFF00 && this.joypad) return this.joypad.readRegister();
      if (addr === 0xFF4D) return (this.doubleSpeed ? 0x80 : 0) | (this.speedSwitchArmed ? 0x01 : 0) | 0x7E;
      if (addr === 0xFF4F) return this.vramBank | 0xFE;
      if (addr === 0xFF55) return this.io[0x55]; // transfer-complete state left by the last HDMA/GDMA write
      if (addr === 0xFF68) return (this.bgPaletteIndex & 0x3F) | (this.bgPaletteAutoInc ? 0x80 : 0) | 0x40;
      if (addr === 0xFF69) return this.bgPalette[this.bgPaletteIndex];
      if (addr === 0xFF6A) return (this.objPaletteIndex & 0x3F) | (this.objPaletteAutoInc ? 0x80 : 0) | 0x40;
      if (addr === 0xFF6B) return this.objPalette[this.objPaletteIndex];
      if (addr === 0xFF70) return this.wramBank | 0xF8;
      return this.io[addr - 0xFF00];
    }
    if (addr < 0xFFFF) return this.hram[addr - 0xFF80];
    return this.ie;
  }

  writeByte(addr, value) {
    addr &= 0xFFFF;
    value &= 0xFF;
    if (addr < 0x8000) { if (this.mbc) this.mbc.writeControl(addr, value); return; }
    if (addr < 0xA000) return void (this.vram[this.vramBank][addr - 0x8000] = value);
    if (addr < 0xC000) { if (this.mbc) this.mbc.writeRAM(addr, value); else this.eram[addr - 0xA000] = value; return; }
    if (addr < 0xE000) return void this.writeWRAM(addr - 0xC000, value);
    if (addr < 0xFE00) return void this.writeWRAM(addr - 0xE000, value); // echo RAM
    if (addr < 0xFEA0) return void (this.oam[addr - 0xFE00] = value);
    if (addr < 0xFF00) return; // unusable
    if (addr < 0xFF80) {
      if (addr === 0xFF04) {
        // DIV: any write resets it to 0, regardless of the value written.
        // The Timer owns the real 16-bit internal counter this derives from,
        // so just flag it and let Timer.step() do the actual reset.
        this.io[0x04] = 0;
        this.divWriteReset = true;
        return;
      }
      if (addr === 0xFF46) {
        // OAM DMA: writing here starts a fast 160-byte copy from
        // (value * 0x100) into OAM (FE00-FE9F). This is how games load
        // sprite data every frame — without it OAM stays empty and no
        // sprites (player, NPCs, etc.) ever appear, even though
        // backgrounds render fine. Real hardware does this over 160
        // cycles with the CPU restricted to HRAM; we do it instantly,
        // which is a simplification but produces the correct end state.
        const src = value << 8;
        for (let i = 0; i < 0xA0; i++) this.oam[i] = this.readByte(src + i);
        this.io[0x46] = value;
        return;
      }
      if (addr === 0xFF4D) { // KEY1: arm/disarm a CGB double-speed switch
        this.speedSwitchArmed = (value & 0x01) !== 0;
        return;
      }
      if (addr === 0xFF4F) { // VBK: VRAM bank select (CGB only, harmless on DMG)
        this.vramBank = value & 0x01;
        return;
      }
      if (addr === 0xFF51) { this.hdmaSrc = (this.hdmaSrc & 0x00FF) | (value << 8); return; }
      if (addr === 0xFF52) { this.hdmaSrc = (this.hdmaSrc & 0xFF00) | (value & 0xF0); return; }
      if (addr === 0xFF53) { this.hdmaDst = (this.hdmaDst & 0x00FF) | ((value & 0x1F) << 8); return; }
      if (addr === 0xFF54) { this.hdmaDst = (this.hdmaDst & 0xFF00) | (value & 0xF0); return; }
      if (addr === 0xFF55) {
        // HDMA5: triggers a VRAM transfer of ((value&0x7F)+1)*16 bytes from
        // hdmaSrc to 0x8000+hdmaDst. We perform General-Purpose and
        // HBlank-mode transfers identically (immediately, in full) — see
        // the class-level comment on why that's a deliberate simplification.
        const length = ((value & 0x7F) + 1) * 16;
        const dst = 0x8000 + (this.hdmaDst & 0x1FF0);
        for (let i = 0; i < length; i++) {
          this.writeByte(dst + i, this.readByte((this.hdmaSrc & 0xFFF0) + i));
        }
        this.io[0x55] = 0xFF; // report "transfer complete, none pending"
        return;
      }
      if (addr === 0xFF68) { this.bgPaletteIndex = value & 0x3F; this.bgPaletteAutoInc = (value & 0x80) !== 0; return; }
      if (addr === 0xFF69) {
        this.bgPalette[this.bgPaletteIndex] = value;
        if (this.bgPaletteAutoInc) this.bgPaletteIndex = (this.bgPaletteIndex + 1) & 0x3F;
        return;
      }
      if (addr === 0xFF6A) { this.objPaletteIndex = value & 0x3F; this.objPaletteAutoInc = (value & 0x80) !== 0; return; }
      if (addr === 0xFF6B) {
        this.objPalette[this.objPaletteIndex] = value;
        if (this.objPaletteAutoInc) this.objPaletteIndex = (this.objPaletteIndex + 1) & 0x3F;
        return;
      }
      if (addr === 0xFF70) { // SVBK: WRAM bank select for D000-DFFF, 0 behaves as 1
        const bank = value & 0x07;
        this.wramBank = bank === 0 ? 1 : bank;
        return;
      }
      this.io[addr - 0xFF00] = value;
      if (this.apu && addr >= 0xFF10 && addr <= 0xFF3F) this.apu.onRegisterWrite(addr - 0xFF00, value);
      return;
    }
    if (addr < 0xFFFF) return void (this.hram[addr - 0xFF80] = value);
    this.ie = value;
  }

  readWord(addr) {
    return this.readByte(addr) | (this.readByte(addr + 1) << 8);
  }

  writeWord(addr, value) {
    this.writeByte(addr, value & 0xFF);
    this.writeByte(addr + 1, (value >> 8) & 0xFF);
  }

  // Sets a bit in the IF register (0xFF0F). bit: 0=VBlank 1=STAT 2=Timer 3=Serial 4=Joypad.
  requestInterrupt(bit) {
    this.io[0x0F] |= (1 << bit);
  }
}
