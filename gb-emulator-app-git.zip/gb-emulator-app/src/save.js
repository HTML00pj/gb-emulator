// Save persistence for battery-backed cartridge RAM (the RAM inside the
// cartridge that keeps your save file alive on real hardware because there's
// a tiny battery soldered in). We don't have a battery, so we use
// localStorage instead — same idea, same result from the player's side.
//
// Wired up for every battery-backed MBC this emulator implements: MBC1,
// MBC3, and MBC5. Plain ROM-only carts have no battery to begin with, so
// there's nothing to persist for those.

const SAVE_PREFIX = 'gbsave:';
const BATTERY_CART_TYPES = new Set([
  0x03,             // MBC1+RAM+BATTERY
  0x06,             // MBC2+BATTERY (MBC2's RAM is built-in, always battery-backed when this flag is set)
  0x10, 0x13,       // MBC3+TIMER+RAM+BATTERY, MBC3+RAM+BATTERY
  0x1B, 0x1E,       // MBC5+RAM+BATTERY, MBC5+RUMBLE+RAM+BATTERY
]);

// Cartridge title lives at header bytes 0x134-0x143 (16 bytes, padded with
// 0x00). Using it as the save key means different games don't collide, and
// re-loading the same game finds its old save automatically.
function getSaveKey(romBytes) {
  let title = '';
  for (let i = 0x134; i <= 0x143; i++) {
    const byte = romBytes[i];
    if (byte === 0) break;
    title += String.fromCharCode(byte);
  }
  return SAVE_PREFIX + (title.trim() || 'untitled');
}

function hasBattery(romBytes) {
  return BATTERY_CART_TYPES.has(romBytes[0x147]);
}

// Call once, right after mmu.loadROM(bytes) — restores any existing save
// into the MBC's RAM before the game starts running.
export function loadSave(mmu, romBytes) {
  if (!hasBattery(romBytes) || !mmu.mbc) return;

  const key = getSaveKey(romBytes);
  const stored = localStorage.getItem(key);
  if (!stored) return;

  try {
    const bytes = JSON.parse(stored);
    mmu.mbc.ram.set(bytes.slice(0, mmu.mbc.ram.length));
  } catch (err) {
    console.warn('Save data for this cartridge was corrupted, starting fresh.', err);
  }
}

// Call periodically (and on quit) — writes current RAM state out.
// Cheap to call often: it's just a JSON array write to localStorage.
export function writeSave(mmu, romBytes) {
  if (!hasBattery(romBytes) || !mmu.mbc) return;
  const key = getSaveKey(romBytes);
  localStorage.setItem(key, JSON.stringify(Array.from(mmu.mbc.ram)));
}
