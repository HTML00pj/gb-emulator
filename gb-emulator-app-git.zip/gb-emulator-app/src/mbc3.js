// MBC3 — similar to MBC1 but simpler bank switching (full 7-bit ROM bank
// number, no separate banking-mode quirk) plus an optional Real-Time Clock
// (RTC) for games that track in-game time even while powered off.
//
// Control "registers" (writes into ROM address space):
//   0x0000-0x1FFF  RAM/RTC enable     (lower nibble 0x0A enables, else disables)
//   0x2000-0x3FFF  ROM bank number    (7 bits, 0 treated as 1 — same quirk as MBC1)
//   0x4000-0x5FFF  RAM bank number (0x00-0x03), OR an RTC register select (0x08-0x0C)
//   0x6000-0x7FFF  Latch clock data — writing 0x00 then 0x01 "snapshots" the
//                  live RTC into the latched registers that 0xA000-0xBFFF reads
//                  while an RTC register (0x08-0x0C) is selected

const RTC_SECONDS = 0x08, RTC_MINUTES = 0x09, RTC_HOURS = 0x0A, RTC_DAY_LOW = 0x0B, RTC_DAY_HIGH = 0x0C;

export class MBC3 {
  constructor(romBytes) {
    this.rom = romBytes;
    this.ram = new Uint8Array(0x8000); // 4 banks x 8KB
    this.ramEnabled = false;
    this.romBank = 1;
    this.ramBankOrRTCSelect = 0; // 0x00-0x03 = RAM bank, 0x08-0x0C = RTC register

    // RTC state — real seconds/minutes/hours/days since the clock was started.
    // `latched` is a frozen snapshot taken on the 0x00-then-0x01 latch write,
    // which is what 0xA000-0xBFFF actually reads from (matches real hardware:
    // the running clock can keep ticking without the game seeing it change
    // mid-read).
    this.rtc = { seconds: 0, minutes: 0, hours: 0, days: 0, halted: false };
    this.latched = { ...this.rtc };
    this.latchState = 0xFF; // tracks the 0x00->0x01 write sequence

    this.lastRealTime = Date.now();
  }

  // Advances the live RTC based on wall-clock time elapsed. Call this
  // periodically (e.g. once per frame) so the clock keeps real time even
  // while paused/slow, similar to real hardware's independent crystal.
  tick() {
    if (this.rtc.halted) { this.lastRealTime = Date.now(); return; }
    const now = Date.now();
    let elapsedSeconds = Math.floor((now - this.lastRealTime) / 1000);
    if (elapsedSeconds <= 0) return;
    this.lastRealTime += elapsedSeconds * 1000;

    this.rtc.seconds += elapsedSeconds;
    this.rtc.minutes += Math.floor(this.rtc.seconds / 60); this.rtc.seconds %= 60;
    this.rtc.hours += Math.floor(this.rtc.minutes / 60); this.rtc.minutes %= 60;
    this.rtc.days += Math.floor(this.rtc.hours / 24); this.rtc.hours %= 24;
    // Real hardware carries days up to a 9-bit counter (0-511) with an
    // overflow flag; not modeled here since almost no game depends on it.
  }

  readROM(addr) {
    if (addr < 0x4000) return this.rom[addr] ?? 0xFF;
    const offset = this.romBank * 0x4000 + (addr - 0x4000);
    return this.rom[offset] ?? 0xFF;
  }

  writeControl(addr, value) {
    if (addr < 0x2000) {
      this.ramEnabled = (value & 0x0F) === 0x0A;
    } else if (addr < 0x4000) {
      this.romBank = (value & 0x7F) || 1; // 0 => treated as 1
    } else if (addr < 0x6000) {
      this.ramBankOrRTCSelect = value;
    } else if (addr < 0x8000) {
      // Latch sequence: writing 0x00 then 0x01 snapshots live RTC -> latched.
      if (this.latchState === 0x00 && value === 0x01) {
        this.tick();
        this.latched = { ...this.rtc };
      }
      this.latchState = value;
    }
  }

  readRAM(addr) {
    if (!this.ramEnabled) return 0xFF;
    const sel = this.ramBankOrRTCSelect;

    if (sel <= 0x03) {
      return this.ram[sel * 0x2000 + (addr - 0xA000)];
    }
    switch (sel) {
      case RTC_SECONDS: return this.latched.seconds;
      case RTC_MINUTES: return this.latched.minutes;
      case RTC_HOURS: return this.latched.hours;
      case RTC_DAY_LOW: return this.latched.days & 0xFF;
      case RTC_DAY_HIGH: return ((this.latched.days >> 8) & 0x01) | (this.latched.halted ? 0x40 : 0);
      default: return 0xFF;
    }
  }

  writeRAM(addr, value) {
    if (!this.ramEnabled) return;
    const sel = this.ramBankOrRTCSelect;

    if (sel <= 0x03) {
      this.ram[sel * 0x2000 + (addr - 0xA000)] = value & 0xFF;
      return;
    }
    switch (sel) {
      case RTC_SECONDS: this.rtc.seconds = value & 0x3F; break;
      case RTC_MINUTES: this.rtc.minutes = value & 0x3F; break;
      case RTC_HOURS: this.rtc.hours = value & 0x1F; break;
      case RTC_DAY_LOW: this.rtc.days = (this.rtc.days & 0x100) | value; break;
      case RTC_DAY_HIGH:
        this.rtc.days = (this.rtc.days & 0xFF) | ((value & 0x01) << 8);
        this.rtc.halted = (value & 0x40) !== 0;
        break;
    }
  }
}
