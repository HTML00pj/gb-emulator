// MBC2 — an older, simpler MBC used in some early GB games. Two things make
// it different from MBC1/MBC3/MBC5:
//   1. Its ROM/RAM-enable control register is selected by *which address*
//      within 0x0000-0x3FFF is written to, based on bit 8 of that address
//      (bit8=0 -> RAM enable, bit8=1 -> ROM bank), not by which range like
//      other MBCs.
//   2. It has built-in RAM right on the cartridge: only 512 half-bytes
//      (nibbles). Only the low 4 bits of each byte are meaningful; reads
//      always report the upper 4 bits as set (0xF0-0xFF range).
//
// Control:
//   0x0000-0x3FFF, address bit 8 = 0  RAM enable (lower nibble 0x0A enables)
//   0x0000-0x3FFF, address bit 8 = 1  ROM bank number (4 bits, 0 treated as 1)

export class MBC2 {
  constructor(romBytes) {
    this.rom = romBytes;
    this.ram = new Uint8Array(512); // built into the cartridge itself, not a separate chip
    this.ramEnabled = false;
    this.romBank = 1;
  }

  readROM(addr) {
    if (addr < 0x4000) return this.rom[addr] ?? 0xFF;
    const offset = this.romBank * 0x4000 + (addr - 0x4000);
    return this.rom[offset] ?? 0xFF;
  }

  writeControl(addr, value) {
    if (addr >= 0x4000) return; // MBC2 only decodes 0x0000-0x3FFF
    if (addr & 0x0100) {
      this.romBank = (value & 0x0F) || 1; // 0 treated as 1, same quirk as MBC1
    } else {
      this.ramEnabled = (value & 0x0F) === 0x0A;
    }
  }

  readRAM(addr) {
    if (!this.ramEnabled) return 0xFF;
    // Only 512 nibbles, mirrored across the full 0xA000-0xBFFF window on
    // real hardware; upper 4 bits always read back as 1.
    return 0xF0 | (this.ram[(addr - 0xA000) & 0x1FF] & 0x0F);
  }

  writeRAM(addr, value) {
    if (!this.ramEnabled) return;
    this.ram[(addr - 0xA000) & 0x1FF] = value & 0x0F;
  }
}
