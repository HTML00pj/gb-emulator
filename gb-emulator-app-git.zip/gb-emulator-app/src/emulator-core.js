import { MMU } from './mmu.js';
import { CPU } from './cpu.js';
import { PPU } from './ppu.js';
import { Timer } from './timer.js';
import { Joypad } from './joypad.js';
import { APU } from './apu.js';
import { loadSave, writeSave } from './save.js';

const CYCLES_PER_FRAME = 70224; // ~4.194304 MHz / 59.7 fps
const AUTOSAVE_INTERVAL_MS = 5000;

const canvas = document.getElementById('screen');
const ctx = canvas.getContext('2d');
const imageData = ctx.createImageData(160, 144);
const versionBadge = document.getElementById('version-badge');
const debugLine = document.getElementById('debug-line');

// If you can see this text change to a build tag on the page, you're running
// the current file. If the badge stays stuck on "loading..." after a refresh,
// the browser is still serving an old cached copy of this script.
if (versionBadge) versionBadge.textContent = 'build: 2026-08-06-debug';

let mmu, cpu, ppu, timer, joypad, apu, running = false;
let currentROMBytes = null;
let autosaveTimer = null;
let frameCount = 0;

// Default keyboard mapping — arrows for dpad, Z/X for A/B, Enter/Shift for Start/Select.
const KEY_MAP = {
  ArrowRight: 'right', ArrowLeft: 'left', ArrowUp: 'up', ArrowDown: 'down',
  z: 'a', Z: 'a', x: 'b', X: 'b',
  Enter: 'start', Shift: 'select',
};

window.addEventListener('keydown', (e) => {
  const button = KEY_MAP[e.key];
  if (button && joypad) { joypad.setButton(button, true); e.preventDefault(); }
});
window.addEventListener('keyup', (e) => {
  const button = KEY_MAP[e.key];
  if (button && joypad) { joypad.setButton(button, false); e.preventDefault(); }
});

// Flush the save right before the window closes, so quitting never loses progress.
window.addEventListener('beforeunload', () => {
  if (mmu && currentROMBytes) writeSave(mmu, currentROMBytes);
});

function loadROM(bytes) {
  if (autosaveTimer) clearInterval(autosaveTimer);
  if (mmu && currentROMBytes) writeSave(mmu, currentROMBytes); // flush any previous game's save first

  mmu = new MMU();
  cpu = new CPU(mmu);
  ppu = new PPU(mmu);
  timer = new Timer(mmu);
  joypad = new Joypad(mmu);
  apu = new APU(mmu);
  mmu.joypad = joypad;
  mmu.apu = apu;
  mmu.loadROM(bytes);
  currentROMBytes = bytes;

  // Games check register A after boot to detect real CGB hardware (0x11)
  // vs DMG/MGB (0x01) and choose whether to use color assets. We skip the
  // boot ROM entirely, so we have to set this ourselves once we know from
  // the cartridge header whether this is a CGB(-compatible) game.
  if (mmu.isCGB) cpu.a = 0x11;

  loadSave(mmu, bytes);
  autosaveTimer = setInterval(() => writeSave(mmu, currentROMBytes), AUTOSAVE_INTERVAL_MS);

  // Debug hook: lets you inspect live emulator state from the browser console,
  // e.g. gb.cpu.pc.toString(16), gb.mmu.io[0x40].toString(16) for LCDC,
  // gb.isRunning() to check if the loop is still going, gb.frameCount() to
  // see if frames are actually advancing (both are functions since `running`
  // and `frameCount` are reassigned after this object is created).
  window.gb = { mmu, cpu, ppu, timer, joypad, apu, isRunning: () => running, frameCount: () => frameCount };

  if (debugLine) debugLine.textContent = 'ROM loaded, starting...';

  apu.start(); // safe here: called from the file input's change event, a user gesture
  running = true;
  requestAnimationFrame(frame);
}

function frame() {
  if (!running) return;

  let cyclesThisFrame = 0;
  try {
    while (cyclesThisFrame < CYCLES_PER_FRAME) {
      const cycles = cpu.step();
      // On CGB double-speed, the CPU runs twice as fast but the PPU/Timer/
      // APU don't — they still advance at the normal dot rate. cpu.step()
      // returns cycles at the CPU's current speed, so halve it before
      // feeding the other components when double speed is active.
      const busCycles = cpu.doubleSpeed ? cycles >> 1 : cycles;
      ppu.step(busCycles);
      timer.step(busCycles);
      apu.step(busCycles);
      cyclesThisFrame += busCycles;
    }
  } catch (err) {
    console.error(err);
    if (debugLine) debugLine.textContent = `CRASHED: ${err.message}`;
    running = false;
    return;
  }

  imageData.data.set(ppu.framebuffer);
  ctx.putImageData(imageData, 0, 0);
  frameCount++;

  if (mmu.mbc && mmu.mbc.tick) mmu.mbc.tick(); // advance MBC3's real-time clock, if this cart has one

  if (debugLine && frameCount % 10 === 0) {
    const pc = cpu.pc.toString(16).padStart(4, '0');
    const lcdc = mmu.io[0x40].toString(16).padStart(2, '0');
    debugLine.textContent = `running: ${running} | frame: ${frameCount} | PC: 0x${pc} | LCDC: 0x${lcdc}`;
  }

  requestAnimationFrame(frame);
}

export function startROM(bytes) {
  loadROM(bytes);
}
