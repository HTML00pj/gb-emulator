import { parseROMHeader } from './rom-header.js';
import { startROM } from './emulator-core.js';

// ROM library is session-only (not persisted to disk) — matches the scope
// of the original design, and avoids trying to stash multi-megabyte ROM
// files in localStorage, which isn't built for that.
const library = []; // { name, bytes, header }
let selectedIndex = -1;

const tabs = document.querySelectorAll('.tab-button');
const views = {
  library: document.getElementById('view-library'),
  emulator: document.getElementById('view-emulator'),
  settings: document.getElementById('view-settings'),
};
const dropZone = document.getElementById('drop-zone');
const fileInput = document.getElementById('rom-file-input');
const libraryGrid = document.getElementById('library-grid');

function switchView(name) {
  for (const tab of tabs) tab.classList.toggle('active', tab.dataset.view === name);
  for (const [key, el] of Object.entries(views)) el.classList.toggle('hidden', key !== name);
}

tabs.forEach((tab) => {
  tab.addEventListener('click', () => switchView(tab.dataset.view));
});

async function addROM(file) {
  const buf = await file.arrayBuffer();
  const bytes = new Uint8Array(buf);
  const header = parseROMHeader(bytes);
  library.push({ name: file.name, bytes, header });
  selectedIndex = library.length - 1;
  renderLibrary();
  playSelected(); // jump straight into the game, matching drag-and-drop-to-play convenience
}

function playSelected() {
  if (selectedIndex < 0) return;
  startROM(library[selectedIndex].bytes);
  switchView('emulator');
}

function renderLibrary() {
  libraryGrid.innerHTML = '';
  library.forEach((entry, i) => {
    const card = document.createElement('div');
    card.className = 'rom-card' + (i === selectedIndex ? ' selected' : '');
    card.innerHTML = `
      <div class="rom-card-badge">${entry.header.isCGB ? 'COLOR' : 'DMG'}</div>
      <div class="rom-card-title">${entry.header.title}</div>
      <div class="rom-card-mbc">${entry.header.mbcName}</div>
    `;
    card.addEventListener('click', () => {
      selectedIndex = i;
      playSelected();
    });
    libraryGrid.appendChild(card);
  });
}

// --- Drag and drop ---
['dragenter', 'dragover'].forEach((evt) => {
  dropZone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropZone.classList.add('drag-active');
  });
});
['dragleave', 'drop'].forEach((evt) => {
  dropZone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropZone.classList.remove('drag-active');
  });
});
dropZone.addEventListener('drop', (e) => {
  const file = e.dataTransfer.files[0];
  if (file) addROM(file);
});
dropZone.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (file) addROM(file);
});

switchView('library');
