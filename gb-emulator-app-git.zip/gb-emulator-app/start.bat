@echo off
echo Starting GB Emulator (fresh)...
cd /d "%~dp0"
if not exist node_modules (
  echo Installing dependencies, first run only...
  call npm install
)
call npm start
pause
