// Reads just the cartridge header fields needed for the library view —
// mirrors the CartridgeHeader parsing logic: title at 0x134, cart type at
// 0x147, ROM/RAM size at 0x148/0x149. Full ROM loading (all bytes, not
// just the header) is handled separately in emulator-core.js.

const MBC_NAMES = {
  0x00: 'ROM only', 0x01: 'MBC1', 0x02: 'MBC1+RAM', 0x03: 'MBC1+RAM+BATTERY',
  0x05: 'MBC2', 0x06: 'MBC2+BATTERY',
  0x0F: 'MBC3+TIMER+BATTERY', 0x10: 'MBC3+TIMER+RAM+BATTERY', 0x11: 'MBC3', 0x12: 'MBC3+RAM', 0x13: 'MBC3+RAM+BATTERY',
  0x19: 'MBC5', 0x1A: 'MBC5+RAM', 0x1B: 'MBC5+RAM+BATTERY', 0x1C: 'MBC5+RUMBLE', 0x1D: 'MBC5+RUMBLE+RAM', 0x1E: 'MBC5+RUMBLE+RAM+BATTERY',
};

export function parseROMHeader(bytes) {
  let title = '';
  for (let i = 0x134; i <= 0x143; i++) {
    const byte = bytes[i] || 0;
    if (byte === 0) break; // titles are null-padded, not always the full 16 bytes
    title += String.fromCharCode(byte);
  }
  title = title.trim() || '(untitled)';

  const cartType = bytes[0x147] ?? 0;
  const isCGB = bytes[0x143] === 0x80 || bytes[0x143] === 0xC0;

  return {
    title,
    cartType,
    mbcName: MBC_NAMES[cartType] ?? `Unknown (0x${cartType.toString(16)})`,
    isCGB,
  };
}
