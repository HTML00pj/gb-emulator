// Sharp LR35902 CPU — a modified Z80.
// Registers are 8-bit, paired into 16-bit: AF, BC, DE, HL. Plus SP and PC (16-bit).
// Flags (F register bits): Z (7) N (6) H (5) C (4)

const FLAG_Z = 0x80, FLAG_N = 0x40, FLAG_H = 0x20, FLAG_C = 0x10;

// Register-code order used throughout the GB opcode table for the 3-bit
// operand fields: 0=B 1=C 2=D 3=E 4=H 5=L 6=(HL) 7=A
const R_B = 0, R_C = 1, R_D = 2, R_E = 3, R_H = 4, R_L = 5, R_HL = 6, R_A = 7;

export class CPU {
  constructor(mmu) {
    this.mmu = mmu;
    this.reset();
    this.opcodes = {};
    this.buildOpcodes();
  }

  reset() {
    // Post-boot-ROM register state (DMG)
    this.a = 0x01; this.f = 0xB0;
    this.b = 0x00; this.c = 0x13;
    this.d = 0x00; this.e = 0xD8;
    this.h = 0x01; this.l = 0x4D;
    this.sp = 0xFFFE;
    this.pc = 0x0100; // skip boot ROM, start at cartridge entry point
    this.halted = false;
    this.ime = false; // interrupt master enable
    this.imeScheduled = 0; // counts down after EI; ime actually flips true when this hits 0 (see step())
    this.cycles = 0;
    this.doubleSpeed = false; // CGB only; toggled via STOP after KEY1 arms a switch
  }

  // --- 16-bit register pair helpers ---
  get af() { return (this.a << 8) | this.f; }
  get bc() { return (this.b << 8) | this.c; }
  get de() { return (this.d << 8) | this.e; }
  get hl() { return (this.h << 8) | this.l; }
  set bc(v) { this.b = (v >> 8) & 0xFF; this.c = v & 0xFF; }
  set de(v) { this.d = (v >> 8) & 0xFF; this.e = v & 0xFF; }
  set hl(v) { this.h = (v >> 8) & 0xFF; this.l = v & 0xFF; }

  getFlag(mask) { return (this.f & mask) !== 0; }
  setFlag(mask, on) { this.f = on ? (this.f | mask) : (this.f & ~mask); }

  fetch8() {
    const v = this.mmu.readByte(this.pc);
    this.pc = (this.pc + 1) & 0xFFFF;
    return v;
  }

  fetch16() {
    const v = this.mmu.readWord(this.pc);
    this.pc = (this.pc + 2) & 0xFFFF;
    return v;
  }

  // Runs one instruction (or services a pending interrupt), returns cycles consumed.
  step() {
    const interruptCycles = this.handleInterrupts();
    if (interruptCycles) return interruptCycles;

    if (this.halted) return 4; // still ticks while halted, waiting for interrupt

    const opcode = this.fetch8();
    const handler = this.opcodes[opcode];
    if (!handler) {
      throw new Error(`Unimplemented opcode 0x${opcode.toString(16).padStart(2, '0')} at PC=0x${(this.pc - 1).toString(16)}`);
    }
    const cycles = handler();

    // EI's effect is delayed: IME only actually flips true once the
    // instruction *after* EI has finished executing, not EI itself. See
    // op[0xFB] below, which sets imeScheduled=2 instead of setting ime
    // directly. (RETI is different — it enables IME immediately.)
    if (this.imeScheduled > 0 && --this.imeScheduled === 0) this.ime = true;

    return cycles;
  }

  // Checks IE (0xFFFF) against IF (0xFF0F, the 5 low bits: VBlank, STAT, Timer,
  // Serial, Joypad) and dispatches to the matching interrupt vector if IME is on.
  // A pending enabled interrupt also wakes the CPU from HALT even if IME is off.
  handleInterrupts() {
    const ifReg = this.mmu.io[0x0F];
    const ieReg = this.mmu.ie;
    const pending = ifReg & ieReg & 0x1F;

    if (pending && this.halted) this.halted = false;
    if (!this.ime || !pending) return 0;

    const vectors = [0x40, 0x48, 0x50, 0x58, 0x60]; // VBlank, LCD STAT, Timer, Serial, Joypad
    for (let bit = 0; bit < 5; bit++) {
      if (pending & (1 << bit)) {
        this.ime = false;
        this.mmu.io[0x0F] &= ~(1 << bit); // acknowledge
        this.sp = (this.sp - 2) & 0xFFFF;
        this.mmu.writeWord(this.sp, this.pc);
        this.pc = vectors[bit];
        return 20;
      }
    }
    return 0;
  }

  // --- 8-bit register-code read/write, used by the programmatically-built ops below ---
  // code 6 = (HL), the only "register" operand that touches memory.
  readR(code) {
    switch (code) {
      case R_B: return this.b;
      case R_C: return this.c;
      case R_D: return this.d;
      case R_E: return this.e;
      case R_H: return this.h;
      case R_L: return this.l;
      case R_HL: return this.mmu.readByte(this.hl);
      case R_A: return this.a;
    }
  }

  writeR(code, value) {
    value &= 0xFF;
    switch (code) {
      case R_B: this.b = value; return;
      case R_C: this.c = value; return;
      case R_D: this.d = value; return;
      case R_E: this.e = value; return;
      case R_H: this.h = value; return;
      case R_L: this.l = value; return;
      case R_HL: this.mmu.writeByte(this.hl, value); return;
      case R_A: this.a = value; return;
    }
  }

  // --- ALU helpers (set flags the way the real hardware does) ---
  addA(value, useCarry = false) {
    const carryIn = useCarry && this.getFlag(FLAG_C) ? 1 : 0;
    const result = this.a + value + carryIn;
    this.setFlag(FLAG_H, ((this.a & 0xF) + (value & 0xF) + carryIn) > 0xF);
    this.setFlag(FLAG_C, result > 0xFF);
    this.a = result & 0xFF;
    this.setFlag(FLAG_Z, this.a === 0);
    this.setFlag(FLAG_N, false);
  }

  subA(value, useCarry = false, store = true) {
    const carryIn = useCarry && this.getFlag(FLAG_C) ? 1 : 0;
    const result = this.a - value - carryIn;
    this.setFlag(FLAG_H, ((this.a & 0xF) - (value & 0xF) - carryIn) < 0);
    this.setFlag(FLAG_C, result < 0);
    this.setFlag(FLAG_Z, (result & 0xFF) === 0);
    this.setFlag(FLAG_N, true);
    if (store) this.a = result & 0xFF;
  }

  andA(value) {
    this.a &= value;
    this.setFlag(FLAG_Z, this.a === 0);
    this.setFlag(FLAG_N, false);
    this.setFlag(FLAG_H, true);
    this.setFlag(FLAG_C, false);
  }

  xorA(value) {
    this.a = (this.a ^ value) & 0xFF;
    this.setFlag(FLAG_Z, this.a === 0);
    this.setFlag(FLAG_N, false);
    this.setFlag(FLAG_H, false);
    this.setFlag(FLAG_C, false);
  }

  orA(value) {
    this.a = (this.a | value) & 0xFF;
    this.setFlag(FLAG_Z, this.a === 0);
    this.setFlag(FLAG_N, false);
    this.setFlag(FLAG_H, false);
    this.setFlag(FLAG_C, false);
  }

  incR(code) {
    const value = this.readR(code);
    const result = (value + 1) & 0xFF;
    this.setFlag(FLAG_H, (value & 0xF) === 0xF);
    this.setFlag(FLAG_Z, result === 0);
    this.setFlag(FLAG_N, false);
    this.writeR(code, result);
  }

  decR(code) {
    const value = this.readR(code);
    const result = (value - 1) & 0xFF;
    this.setFlag(FLAG_H, (value & 0xF) === 0);
    this.setFlag(FLAG_Z, result === 0);
    this.setFlag(FLAG_N, true);
    this.writeR(code, result);
  }

  // --- Build the opcode dispatch table ---
  // Hand-written entries for control flow / special cases, plus programmatically
  // generated blocks for the regular LD r,r' / ALU r / INC r / DEC r grids, since
  // those follow a strict bit-pattern across the whole 0x00-0xBF range.
  buildOpcodes() {
    const op = this.opcodes;

    op[0x00] = () => 4; // NOP

    op[0xC3] = () => { this.pc = this.fetch16(); return 16; }; // JP nn

    op[0x76] = () => { this.halted = true; return 4; }; // HALT

    op[0x10] = () => {
      this.fetch8(); // STOP is followed by a padding byte (usually 0x00), always consumed
      if (this.mmu.speedSwitchArmed) {
        // CGB double-speed switch: games arm this via KEY1 (0xFF4D) then
        // execute STOP to perform the actual switch. Real hardware takes
        // ~128 cycles at the old speed to realign; we approximate that
        // with a fixed cycle cost rather than modeling the realignment.
        this.doubleSpeed = !this.doubleSpeed;
        this.mmu.doubleSpeed = this.doubleSpeed;
        this.mmu.speedSwitchArmed = false;
        return 2050;
      }
      // Plain STOP (rare outside of CGB speed switching) should halt until
      // a button press; we simplify to a no-op so we don't need a separate
      // "stopped" CPU state most games never actually rely on.
      return 4;
    };

    op[0x21] = () => { this.hl = this.fetch16(); return 12; }; // LD HL,nn
    op[0x11] = () => { this.de = this.fetch16(); return 12; }; // LD DE,nn
    op[0x01] = () => { this.bc = this.fetch16(); return 12; }; // LD BC,nn
    op[0x31] = () => { this.sp = this.fetch16(); return 12; }; // LD SP,nn

    op[0x36] = () => { this.mmu.writeByte(this.hl, this.fetch8()); return 12; }; // LD (HL),n

    // --- LD r,n  (immediate 8-bit loads) ---
    const ldImmOpcodes = { [R_B]: 0x06, [R_C]: 0x0E, [R_D]: 0x16, [R_E]: 0x1E, [R_H]: 0x26, [R_L]: 0x2E, [R_A]: 0x3E };
    for (const [regCode, code] of Object.entries(ldImmOpcodes)) {
      const r = Number(regCode);
      op[code] = () => { this.writeR(r, this.fetch8()); return 8; };
    }

    // --- LD r,r'  (0x40-0x7F grid, minus 0x76 which is HALT) ---
    for (let dst = 0; dst <= 7; dst++) {
      for (let src = 0; src <= 7; src++) {
        const code = 0x40 + (dst << 3) + src;
        if (code === 0x76) continue; // HALT, handled above
        const cycles = (dst === R_HL || src === R_HL) ? 8 : 4;
        op[code] = () => { this.writeR(dst, this.readR(src)); return cycles; };
      }
    }

    // --- ALU r  (0x80-0xBF grid): ADD/ADC/SUB/SBC/AND/XOR/OR/CP against A ---
    for (let src = 0; src <= 7; src++) {
      const cycles = (src === R_HL) ? 8 : 4;
      op[0x80 + src] = () => { this.addA(this.readR(src), false); return cycles; };       // ADD A,r
      op[0x88 + src] = () => { this.addA(this.readR(src), true); return cycles; };        // ADC A,r
      op[0x90 + src] = () => { this.subA(this.readR(src), false, true); return cycles; }; // SUB r
      op[0x98 + src] = () => { this.subA(this.readR(src), true, true); return cycles; };  // SBC A,r
      op[0xA0 + src] = () => { this.andA(this.readR(src)); return cycles; };              // AND r
      op[0xA8 + src] = () => { this.xorA(this.readR(src)); return cycles; };              // XOR r
      op[0xB0 + src] = () => { this.orA(this.readR(src)); return cycles; };               // OR r
      op[0xB8 + src] = () => { this.subA(this.readR(src), false, false); return cycles; };// CP r (discard result)
    }

    // --- ALU A,n  (immediate forms) ---
    op[0xC6] = () => { this.addA(this.fetch8(), false); return 8; };        // ADD A,n
    op[0xCE] = () => { this.addA(this.fetch8(), true); return 8; };         // ADC A,n
    op[0xD6] = () => { this.subA(this.fetch8(), false, true); return 8; };  // SUB n
    op[0xDE] = () => { this.subA(this.fetch8(), true, true); return 8; };   // SBC A,n
    op[0xE6] = () => { this.andA(this.fetch8()); return 8; };               // AND n
    op[0xEE] = () => { this.xorA(this.fetch8()); return 8; };               // XOR n
    op[0xF6] = () => { this.orA(this.fetch8()); return 8; };                // OR n
    op[0xFE] = () => { this.subA(this.fetch8(), false, false); return 8; }; // CP n

    // --- INC r / DEC r  (8-bit, single-register forms) ---
    const incDecCodes = [R_B, R_C, R_D, R_E, R_H, R_L, R_HL, R_A];
    incDecCodes.forEach((r, i) => {
      const cycles = (r === R_HL) ? 12 : 4;
      op[0x04 + (i << 3)] = () => { this.incR(r); return cycles; }; // INC r
      op[0x05 + (i << 3)] = () => { this.decR(r); return cycles; }; // DEC r
    });

    // --- 16-bit INC/DEC (no flags affected) ---
    op[0x03] = () => { this.bc = (this.bc + 1) & 0xFFFF; return 8; };
    op[0x13] = () => { this.de = (this.de + 1) & 0xFFFF; return 8; };
    op[0x23] = () => { this.hl = (this.hl + 1) & 0xFFFF; return 8; };
    op[0x33] = () => { this.sp = (this.sp + 1) & 0xFFFF; return 8; };
    op[0x0B] = () => { this.bc = (this.bc - 1) & 0xFFFF; return 8; };
    op[0x1B] = () => { this.de = (this.de - 1) & 0xFFFF; return 8; };
    op[0x2B] = () => { this.hl = (this.hl - 1) & 0xFFFF; return 8; };
    op[0x3B] = () => { this.sp = (this.sp - 1) & 0xFFFF; return 8; };

    // --- Stack push/pop ---
    const push16 = (value) => {
      this.sp = (this.sp - 2) & 0xFFFF;
      this.mmu.writeWord(this.sp, value);
    };
    const pop16 = () => {
      const value = this.mmu.readWord(this.sp);
      this.sp = (this.sp + 2) & 0xFFFF;
      return value;
    };
    op[0xC5] = () => { push16(this.bc); return 16; };   // PUSH BC
    op[0xD5] = () => { push16(this.de); return 16; };   // PUSH DE
    op[0xE5] = () => { push16(this.hl); return 16; };   // PUSH HL
    op[0xF5] = () => { push16(this.af); return 16; };   // PUSH AF
    op[0xC1] = () => { this.bc = pop16(); return 12; }; // POP BC
    op[0xD1] = () => { this.de = pop16(); return 12; }; // POP DE
    op[0xE1] = () => { this.hl = pop16(); return 12; }; // POP HL
    op[0xF1] = () => {                                   // POP AF (low nibble of F is always 0 on real hardware)
      const value = pop16();
      this.a = (value >> 8) & 0xFF;
      this.f = value & 0xF0;
      return 12;
    };

    // --- Unconditional jumps / calls / returns ---
    op[0xE9] = () => { this.pc = this.hl; return 4; }; // JP (HL)
    op[0x18] = () => {                                   // JR n (relative jump)
      const offset = this.signed8(this.fetch8());
      this.pc = (this.pc + offset) & 0xFFFF;
      return 12;
    };
    op[0xCD] = () => {                                   // CALL nn
      const target = this.fetch16();
      push16(this.pc);
      this.pc = target;
      return 24;
    };
    op[0xC9] = () => { this.pc = pop16(); return 16; };                         // RET
    op[0xD9] = () => { this.pc = pop16(); this.ime = true; return 16; };        // RETI

    // --- Conditional jumps / calls / returns ---
    const condNZ = () => !this.getFlag(FLAG_Z);
    const condZ  = () => this.getFlag(FLAG_Z);
    const condNC = () => !this.getFlag(FLAG_C);
    const condC  = () => this.getFlag(FLAG_C);

    op[0x20] = () => { const off = this.signed8(this.fetch8()); if (condNZ()) { this.pc = (this.pc + off) & 0xFFFF; return 12; } return 8; }; // JR NZ,n
    op[0x28] = () => { const off = this.signed8(this.fetch8()); if (condZ())  { this.pc = (this.pc + off) & 0xFFFF; return 12; } return 8; }; // JR Z,n
    op[0x30] = () => { const off = this.signed8(this.fetch8()); if (condNC()) { this.pc = (this.pc + off) & 0xFFFF; return 12; } return 8; }; // JR NC,n
    op[0x38] = () => { const off = this.signed8(this.fetch8()); if (condC())  { this.pc = (this.pc + off) & 0xFFFF; return 12; } return 8; }; // JR C,n

    op[0xC2] = () => { const t = this.fetch16(); if (condNZ()) { this.pc = t; return 16; } return 12; }; // JP NZ,nn
    op[0xCA] = () => { const t = this.fetch16(); if (condZ())  { this.pc = t; return 16; } return 12; }; // JP Z,nn
    op[0xD2] = () => { const t = this.fetch16(); if (condNC()) { this.pc = t; return 16; } return 12; }; // JP NC,nn
    op[0xDA] = () => { const t = this.fetch16(); if (condC())  { this.pc = t; return 16; } return 12; }; // JP C,nn

    op[0xC4] = () => { const t = this.fetch16(); if (condNZ()) { push16(this.pc); this.pc = t; return 24; } return 12; }; // CALL NZ,nn
    op[0xCC] = () => { const t = this.fetch16(); if (condZ())  { push16(this.pc); this.pc = t; return 24; } return 12; }; // CALL Z,nn
    op[0xD4] = () => { const t = this.fetch16(); if (condNC()) { push16(this.pc); this.pc = t; return 24; } return 12; }; // CALL NC,nn
    op[0xDC] = () => { const t = this.fetch16(); if (condC())  { push16(this.pc); this.pc = t; return 24; } return 12; }; // CALL C,nn

    op[0xC0] = () => { if (condNZ()) { this.pc = pop16(); return 20; } return 8; }; // RET NZ
    op[0xC8] = () => { if (condZ())  { this.pc = pop16(); return 20; } return 8; }; // RET Z
    op[0xD0] = () => { if (condNC()) { this.pc = pop16(); return 20; } return 8; }; // RET NC
    op[0xD8] = () => { if (condC())  { this.pc = pop16(); return 20; } return 8; }; // RET C

    // --- RST (call to fixed low-memory vectors, used by interrupt handlers) ---
    [0x00, 0x08, 0x10, 0x18, 0x20, 0x28, 0x30, 0x38].forEach((vector, i) => {
      op[0xC7 + i * 8] = () => { push16(this.pc); this.pc = vector; return 16; };
    });

    // --- Interrupt enable/disable ---
    op[0xF3] = () => { this.ime = false; this.imeScheduled = 0; return 4; }; // DI (also cancels a pending EI)
    op[0xFB] = () => { this.imeScheduled = 2; return 4; };  // EI — see the countdown in step() for why this isn't ime=true directly

    // --- Memory-mapped A loads (used constantly for I/O and globals) ---
    op[0xEA] = () => { this.mmu.writeByte(this.fetch16(), this.a); return 16; };            // LD (nn),A
    op[0xFA] = () => { this.a = this.mmu.readByte(this.fetch16()); return 16; };             // LD A,(nn)
    op[0xE0] = () => { this.mmu.writeByte(0xFF00 + this.fetch8(), this.a); return 12; };     // LDH (n),A
    op[0xF0] = () => { this.a = this.mmu.readByte(0xFF00 + this.fetch8()); return 12; };     // LDH A,(n)
    op[0xE2] = () => { this.mmu.writeByte(0xFF00 + this.c, this.a); return 8; };             // LD (C),A
    op[0xF2] = () => { this.a = this.mmu.readByte(0xFF00 + this.c); return 8; };             // LD A,(C)
    op[0x02] = () => { this.mmu.writeByte(this.bc, this.a); return 8; };                     // LD (BC),A
    op[0x12] = () => { this.mmu.writeByte(this.de, this.a); return 8; };                     // LD (DE),A
    op[0x0A] = () => { this.a = this.mmu.readByte(this.bc); return 8; };                     // LD A,(BC)
    op[0x1A] = () => { this.a = this.mmu.readByte(this.de); return 8; };                     // LD A,(DE)
    op[0x22] = () => { this.mmu.writeByte(this.hl, this.a); this.hl = (this.hl + 1) & 0xFFFF; return 8; }; // LD (HL+),A
    op[0x2A] = () => { this.a = this.mmu.readByte(this.hl); this.hl = (this.hl + 1) & 0xFFFF; return 8; }; // LD A,(HL+)
    op[0x32] = () => { this.mmu.writeByte(this.hl, this.a); this.hl = (this.hl - 1) & 0xFFFF; return 8; }; // LD (HL-),A
    op[0x3A] = () => { this.a = this.mmu.readByte(this.hl); this.hl = (this.hl - 1) & 0xFFFF; return 8; }; // LD A,(HL-)

    // --- ADD HL,rr / ADD SP,n ---
    const addHL = (value) => {
      const result = this.hl + value;
      this.setFlag(FLAG_N, false);
      this.setFlag(FLAG_H, ((this.hl & 0xFFF) + (value & 0xFFF)) > 0xFFF);
      this.setFlag(FLAG_C, result > 0xFFFF);
      this.hl = result & 0xFFFF;
    };
    op[0x09] = () => { addHL(this.bc); return 8; };
    op[0x19] = () => { addHL(this.de); return 8; };
    op[0x29] = () => { addHL(this.hl); return 8; };
    op[0x39] = () => { addHL(this.sp); return 8; };
    op[0xE8] = () => { // ADD SP,n (signed 8-bit immediate)
      const n = this.signed8(this.fetch8());
      const result = this.sp + n;
      this.setFlag(FLAG_Z, false);
      this.setFlag(FLAG_N, false);
      this.setFlag(FLAG_H, ((this.sp & 0xF) + (n & 0xF)) > 0xF);
      this.setFlag(FLAG_C, ((this.sp & 0xFF) + (n & 0xFF)) > 0xFF);
      this.sp = result & 0xFFFF;
      return 16;
    };

    // --- Stack pointer / HL interplay ---
    op[0xF9] = () => { this.sp = this.hl; return 8; };            // LD SP,HL
    op[0xF8] = () => {                                              // LD HL,SP+n
      const n = this.signed8(this.fetch8());
      const result = this.sp + n;
      this.setFlag(FLAG_Z, false);
      this.setFlag(FLAG_N, false);
      this.setFlag(FLAG_H, ((this.sp & 0xF) + (n & 0xF)) > 0xF);
      this.setFlag(FLAG_C, ((this.sp & 0xFF) + (n & 0xFF)) > 0xFF);
      this.hl = result & 0xFFFF;
      return 12;
    };
    op[0x08] = () => { this.mmu.writeWord(this.fetch16(), this.sp); return 20; }; // LD (nn),SP

    // --- Misc single-byte A/flag ops ---
    op[0x2F] = () => { this.a = (~this.a) & 0xFF; this.setFlag(FLAG_N, true); this.setFlag(FLAG_H, true); return 4; }; // CPL
    op[0x37] = () => { this.setFlag(FLAG_N, false); this.setFlag(FLAG_H, false); this.setFlag(FLAG_C, true); return 4; }; // SCF
    op[0x3F] = () => { this.setFlag(FLAG_N, false); this.setFlag(FLAG_H, false); this.setFlag(FLAG_C, !this.getFlag(FLAG_C)); return 4; }; // CCF

    op[0x27] = () => { // DAA — decimal-adjust A after BCD arithmetic
      let a = this.a;
      let correction = 0;
      let setC = false;
      if (this.getFlag(FLAG_H) || (!this.getFlag(FLAG_N) && (a & 0xF) > 9)) correction |= 0x06;
      if (this.getFlag(FLAG_C) || (!this.getFlag(FLAG_N) && a > 0x99)) { correction |= 0x60; setC = true; }
      a = this.getFlag(FLAG_N) ? (a - correction) & 0xFF : (a + correction) & 0xFF;
      this.a = a;
      this.setFlag(FLAG_Z, a === 0);
      this.setFlag(FLAG_H, false);
      this.setFlag(FLAG_C, setC);
      return 4;
    };

    // --- Fast A-only rotates (1-byte forms, distinct from the CB-prefixed RLC A etc:
    //     these never set Z, unlike their CB cousins) ---
    op[0x07] = () => { const c = (this.a & 0x80) !== 0; this.a = ((this.a << 1) | (c ? 1 : 0)) & 0xFF; this.setZNHC(false, false, false, c); return 4; }; // RLCA
    op[0x0F] = () => { const c = (this.a & 0x01) !== 0; this.a = ((this.a >> 1) | (c ? 0x80 : 0)) & 0xFF; this.setZNHC(false, false, false, c); return 4; }; // RRCA
    op[0x17] = () => { const oldC = this.getFlag(FLAG_C) ? 1 : 0; const c = (this.a & 0x80) !== 0; this.a = ((this.a << 1) | oldC) & 0xFF; this.setZNHC(false, false, false, c); return 4; }; // RLA
    op[0x1F] = () => { const oldC = this.getFlag(FLAG_C) ? 0x80 : 0; const c = (this.a & 0x01) !== 0; this.a = ((this.a >> 1) | oldC) & 0xFF; this.setZNHC(false, false, false, c); return 4; }; // RRA

    // --- CB-prefixed table dispatch ---
    this.buildCBOpcodes();
    op[0xCB] = () => {
      const cbCode = this.fetch8();
      const handler = this.cbOpcodes[cbCode];
      if (!handler) throw new Error(`Unimplemented CB opcode 0x${cbCode.toString(16).padStart(2, '0')}`);
      return handler();
    };
  }

  // --- CB-prefixed table: rotates, shifts, and BIT/SET/RES, each across all 8 register codes ---
  buildCBOpcodes() {
    this.cbOpcodes = {};
    const cb = this.cbOpcodes;

    const rlc = (v) => { const c = (v & 0x80) !== 0; const r = ((v << 1) | (c ? 1 : 0)) & 0xFF; this.setZNHC(r === 0, false, false, c); return r; };
    const rrc = (v) => { const c = (v & 0x01) !== 0; const r = ((v >> 1) | (c ? 0x80 : 0)) & 0xFF; this.setZNHC(r === 0, false, false, c); return r; };
    const rl  = (v) => { const oldC = this.getFlag(FLAG_C) ? 1 : 0; const c = (v & 0x80) !== 0; const r = ((v << 1) | oldC) & 0xFF; this.setZNHC(r === 0, false, false, c); return r; };
    const rr  = (v) => { const oldC = this.getFlag(FLAG_C) ? 0x80 : 0; const c = (v & 0x01) !== 0; const r = ((v >> 1) | oldC) & 0xFF; this.setZNHC(r === 0, false, false, c); return r; };
    const sla = (v) => { const c = (v & 0x80) !== 0; const r = (v << 1) & 0xFF; this.setZNHC(r === 0, false, false, c); return r; };
    const sra = (v) => { const c = (v & 0x01) !== 0; const r = ((v >> 1) | (v & 0x80)) & 0xFF; this.setZNHC(r === 0, false, false, c); return r; };
    const swap = (v) => { const r = ((v << 4) | (v >> 4)) & 0xFF; this.setZNHC(r === 0, false, false, false); return r; };
    const srl = (v) => { const c = (v & 0x01) !== 0; const r = (v >> 1) & 0xFF; this.setZNHC(r === 0, false, false, c); return r; };

    const rotateOps = [rlc, rrc, rl, rr, sla, sra, swap, srl];
    rotateOps.forEach((fn, opIndex) => {
      for (let r = 0; r <= 7; r++) {
        const code = opIndex * 8 + r;
        const cycles = (r === R_HL) ? 16 : 8;
        cb[code] = () => { this.writeR(r, fn(this.readR(r))); return cycles; };
      }
    });

    // BIT b,r: 0x40-0x7F. Z = bit is 0, N=0, H=1, C unaffected.
    for (let bit = 0; bit <= 7; bit++) {
      for (let r = 0; r <= 7; r++) {
        const code = 0x40 + bit * 8 + r;
        const cycles = (r === R_HL) ? 12 : 8;
        cb[code] = () => {
          const isSet = (this.readR(r) & (1 << bit)) !== 0;
          this.setFlag(FLAG_Z, !isSet);
          this.setFlag(FLAG_N, false);
          this.setFlag(FLAG_H, true);
          return cycles;
        };
      }
    }

    // RES b,r: 0x80-0xBF. Clears the bit, no flags affected.
    for (let bit = 0; bit <= 7; bit++) {
      for (let r = 0; r <= 7; r++) {
        const code = 0x80 + bit * 8 + r;
        const cycles = (r === R_HL) ? 16 : 8;
        cb[code] = () => { this.writeR(r, this.readR(r) & ~(1 << bit)); return cycles; };
      }
    }

    // SET b,r: 0xC0-0xFF. Sets the bit, no flags affected.
    for (let bit = 0; bit <= 7; bit++) {
      for (let r = 0; r <= 7; r++) {
        const code = 0xC0 + bit * 8 + r;
        const cycles = (r === R_HL) ? 16 : 8;
        cb[code] = () => { this.writeR(r, this.readR(r) | (1 << bit)); return cycles; };
      }
    }
  }

  setZNHC(z, n, h, c) {
    this.setFlag(FLAG_Z, z);
    this.setFlag(FLAG_N, n);
    this.setFlag(FLAG_H, h);
    this.setFlag(FLAG_C, c);
  }

  // Interprets a byte as signed 8-bit (-128..127), used for JR's relative offset.
  signed8(byte) {
    return byte < 0x80 ? byte : byte - 256;
  }
}
