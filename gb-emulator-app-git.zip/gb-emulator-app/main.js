const { app, BrowserWindow } = require('electron');

function createWindow() {
  const win = new BrowserWindow({
    width: 520,
    height: 600,
    resizable: true,
    autoHideMenuBar: true,
    webPreferences: {
      // Needed so the ES module <script type="module"> imports in index.html
      // (import { MMU } from './mmu.js', etc.) can load over the file:// protocol.
      // Fine for a local desktop app you're building yourself; wouldn't be a
      // sensible default for anything loading remote/untrusted content.
      webSecurity: false,
    },
  });

  win.loadFile('index.html');
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
