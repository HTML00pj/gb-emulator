# GB Emulator — Desktop App (Electron)

## First-time setup
You need Node.js installed (nodejs.org — get the LTS version). Then in this
folder:

```
npm install
```

This downloads Electron and electron-builder (a few hundred MB, one-time).

## Run it as an app (no building an .exe yet)
```
npm start
```
This opens the emulator in its own window — no browser, no local server
needed. You'll land on the **Library** tab: drag and drop a `.gb`/`.gbc`
ROM in (or click the drop zone to pick a file), and it'll load straight
into the **Emulator** tab and start playing. Loaded ROMs stay in your
library for the rest of the session — click a card to switch games.

## Build an actual Windows .exe you can install
```
npm run dist
```
This produces an installer in the `dist/` folder (something like
`GB Emulator Setup 1.0.0.exe`). Run that installer and it puts a normal
Windows app on your machine — Start Menu entry, desktop icon, the works.

## Notes
- `webSecurity: false` is set in `main.js` so the emulator's ES module files
  (`src/mmu.js`, `src/cpu.js`, etc.) can load over Electron's `file://`
  protocol without CORS blocking them. That's fine for an app you built
  yourself; just don't point this window at untrusted remote pages.
- Every time you update the emulator's `src/` files, copy them into this
  folder's `src/` (overwriting) before running `npm start` or `npm run dist`
  again — this folder is a separate copy from the plain web version.
