// MBC5 — supports up to 8MB ROM (511 banks) and up to 128KB external RAM.
// The most common cartridge type in later-generation GBC games. Simpler
// than MBC1: no banking-mode switch, and bank 0 really can be selected
// into the switchable window (unlike MBC1's "0 treated as 1" quirk).
//
// Control "registers" aren't real memory — writes into ROM address space are
// intercepted and just change banking state:
//   0x0000-0x1FFF  RAM enable         (lower nibble 0x0A enables, anything else disables)
//   0x2000-0x2FFF  ROM bank number, low 8 bits
//   0x3000-0x3FFF  ROM bank number, bit 8 (only relevant for ROMs over 2MB / 256 banks)
//   0x4000-0x5FFF  RAM bank number (4 bits; some carts also use this for rumble-motor control,
//                                    which we don't emulate — writes just select a RAM bank as normal)

export class MBC5 {
  constructor(romBytes) {
    this.rom = romBytes;
    this.ram = new Uint8Array(0x20000); // 16 banks x 8KB — allocated even if the cart has less
    this.ramEnabled = false;
    this.romBankLow8 = 1;
    this.romBankBit8 = 0;
    this.ramBank = 0;
  }

  get romBank() {
    return (this.romBankBit8 << 8) | this.romBankLow8; // unlike MBC1, bank 0 is valid here — no "treated as 1"
  }

  readROM(addr) {
    if (addr < 0x4000) return this.rom[addr] ?? 0xFF; // fixed bank 0, always
    const offset = this.romBank * 0x4000 + (addr - 0x4000);
    return this.rom[offset] ?? 0xFF;
  }

  writeControl(addr, value) {
    if (addr < 0x2000) {
      this.ramEnabled = (value & 0x0F) === 0x0A;
    } else if (addr < 0x3000) {
      this.romBankLow8 = value;
    } else if (addr < 0x4000) {
      this.romBankBit8 = value & 0x01;
    } else if (addr < 0x6000) {
      this.ramBank = value & 0x0F;
    }
    // 0x6000-0x7FFF: no function on MBC5, writes are ignored
  }

  readRAM(addr) {
    if (!this.ramEnabled) return 0xFF;
    return this.ram[this.ramBank * 0x2000 + (addr - 0xA000)];
  }

  writeRAM(addr, value) {
    if (!this.ramEnabled) return;
    this.ram[this.ramBank * 0x2000 + (addr - 0xA000)] = value & 0xFF;
  }
}
